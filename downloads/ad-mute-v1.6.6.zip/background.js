/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */

// background.js — per-tab state, mute control, manual overrides, live pushes
const tabState = new Map(); // tabId -> { isAd: bool, lastUpdate: number, force: null|boolean, reason: string }

function effectiveState(s) { return s.force != null ? s.force : s.isAd; }

function setMute(tabId, muted) { chrome.tabs.update(tabId, { muted }); }

function ensure(tabId) {
  if (!tabState.has(tabId)) tabState.set(tabId, { isAd: false, lastUpdate: 0, force: null, reason: '' });
  return tabState.get(tabId);
}

function broadcast(tabId){
  const s = ensure(tabId);
  chrome.tabs.get(tabId, (tab) => {
    const payload = {
      type: 'STATE_PUSH',
      tabId,
      isAd: !!s.isAd,
      effective: !!effectiveState(s),
      force: s.force,
      muted: !!tab?.mutedInfo?.muted,
      reason: s.reason || ''
    };
    try { chrome.tabs.sendMessage(tabId, payload, () => { void chrome.runtime.lastError; }); } catch(e){}
    try { chrome.runtime.sendMessage(payload, () => { void chrome.runtime.lastError; }); } catch(e){}
  });
}

function apply(tabId, s, debounce = true) {
  const isAd = effectiveState(s);
  const now = Date.now();
  if (isAd) {
    setMute(tabId, true);
    broadcast(tabId);
  } else {
    const delay = debounce ? 800 : 0;
    const checkAt = now + 700;
    setTimeout(() => {
      const cur = tabState.get(tabId);
      if (!cur) return;
      if (!effectiveState(cur) && (!debounce || cur.lastUpdate <= checkAt)) {
        setMute(tabId, false);
        broadcast(tabId);
      }
    }, delay);
  }
}

function handleAdState(tabId, isAd, reason) {
  const s = ensure(tabId);
  s.isAd = !!isAd;
  s.reason = isAd ? (reason || '') : ''; // clear reason when not an ad
  s.lastUpdate = Date.now();
  if (s.force == null) { apply(tabId, s, true); } else { broadcast(tabId); }
}

function setForce(tabId, value /* null|boolean */) {
  const s = ensure(tabId);
  s.force = value;
  s.lastUpdate = Date.now();
  apply(tabId, s, false);
  broadcast(tabId);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = msg?.tabId ?? sender?.tab?.id ?? null;

  if (msg?.type === "AD_STATE") {
    if (tabId == null) return sendResponse({ ok: false, error: "NO_TAB" });
    handleAdState(tabId, !!msg.isAd, msg.reason);
    return sendResponse({ ok: true });
  }

  if (msg?.type === "FORCE_STATE") {
    if (tabId == null) return sendResponse({ ok: false, error: "NO_TAB" });
    setForce(tabId, msg.force === null ? null : !!msg.force);
    const s = ensure(tabId);
    return sendResponse({ ok: true, force: s.force });
  }

  if (msg?.type === "GET_STATE") {
    if (tabId == null) return sendResponse({ ok: false, error: "NO_TAB" });
    const s = ensure(tabId);
    chrome.tabs.get(tabId, (tab) => {
      sendResponse({
        ok: true,
        isAd: !!s.isAd,
        effective: !!effectiveState(s),
        force: s.force,
        muted: !!tab?.mutedInfo?.muted,
        reason: s.reason || ''
      });
    });
    return true; // async
  }

  if (msg?.type === "OVERLAY_TOGGLE") {
    if (tabId == null) return sendResponse({ ok: false });
    chrome.tabs.sendMessage(tabId, { type: "OVERLAY_TOGGLE" }, () => { void chrome.runtime.lastError; });
    return sendResponse({ ok: true });
  }

  if (msg?.type === "NX_MODE") {
    if (tabId != null) chrome.tabs.sendMessage(tabId, msg, () => { void chrome.runtime.lastError; });
    return sendResponse({ ok: true });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => { tabState.delete(tabId); });

chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-overlay") {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "OVERLAY_TOGGLE" }, () => { void chrome.runtime.lastError; });
    });
  }
});
