/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */
(function() {
  // SAFE MODE: only click an explicit, visible "Skip" button element.
  // No screen-region clicks.

  const state = { isAd: false, lastAction: 0, lastClose: 0 };
  const THROTTLE = 120;

  const send = (isAd, reason) => {
    if (state.isAd === isAd) return;
    state.isAd = isAd;
    chrome.runtime.sendMessage({ type: "AD_STATE", isAd, reason });
  };

  function visible(el){
    if (!el) return false;
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden' || +s.opacity === 0) return false;
    const rects = el.getClientRects();
    if (!(rects && rects.length)) return false;
    const r = rects[0];
    const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh = Math.max(document.documentElement.clientHeight, innerHeight||0);
    return r.width > 0 && r.height > 0 && r.right > 0 && r.bottom > 0 && r.left < vw && r.top < vh;
  }

  function burstClick(target){
    try { target.focus({ preventScroll:true }); } catch(e){}
    try { target.click(); } catch(e){}
    try {
      const r = target.getBoundingClientRect();
      const x = Math.max(1, r.left + r.width/2), y = Math.max(1, r.top + r.height/2);
      ['pointerdown','mousedown','mouseup','click','pointerup'].forEach(type => {
        try { target.dispatchEvent(new MouseEvent(type, { bubbles:true, cancelable:true, clientX:x, clientY:y })); } catch(e){}
      });
    } catch(e){}
  }

  function root(){ return document.querySelector('#movie_player, .html5-video-player'); }

  // Deep selector: descends into shadowRoots recursively (bounded depth)
  function qsaDeep(base, selector, depth=3, out=[]){
    if (!base) return out;
    try { out.push(...base.querySelectorAll(selector)); } catch(e){}
    if (depth <= 0) return out;
    const all = base.querySelectorAll('*');
    for (const el of all){
      const sr = el && el.shadowRoot;
      if (sr){ qsaDeep(sr, selector, depth-1, out); }
    }
    return out;
  }

  const SKIP_SELECTORS = [
    '.ytp-ad-skip-button-modern',
    'button.ytp-ad-skip-button-modern',
    '.ytp-ad-skip-button',
    'button.ytp-ad-skip-button',
    '.ytp-ad-skip-button-container',
    'button.ytp-skip-ad-button',
    '.ytp-skip-ad-button',
    '.ytp-ad-player-overlay .ytp-button',
    '[aria-label*="Skip Ad" i]',
    '[aria-label*="Skip ads" i]',
    '[aria-label*="Skip" i]',
    '[class*="skip-button" i]',
    '[data-tooltip*="Skip" i]'
  ];

  function findSkipButton(){
    const r = root(); if (!r) return null;
    const nodes = [];
    for (const sel of SKIP_SELECTORS){
      qsaDeep(r, sel, 4, nodes);
    }
    for (const el of nodes){
      const candidate = el.matches('button,.ytp-button,[role="button"]')
        ? el
        : (el.querySelector && el.querySelector('button,.ytp-button,[role="button"]')) || el;
      if (!candidate || candidate.disabled) continue;
      const t = (candidate.innerText || candidate.textContent || '').trim().toLowerCase();
      const a = (candidate.getAttribute && (candidate.getAttribute('aria-label')||'')).toLowerCase();
      if (!t && !a) continue;
      if (!/skip/.test(t) && !/skip/.test(a)) continue;
      if (!visible(candidate)) continue;
      return candidate;
    }
    return null;
  }

  function findOverlayClose(){
    const r = root(); if (!r) return null;
    const sels = [
      '.ytp-ad-overlay-close-button',
      '.ytp-ad-overlay-close-container',
      '.ytp-ad-close-button',
      '.ytp-ad-overlay-close-button .ytp-button',
      '[aria-label*="Close" i].ytp-button'
    ];
    for (const sel of sels){
      const nodes = qsaDeep(r, sel, 3, []);
      for (const el of nodes){ if (visible(el)) return el; }
    }
    return null;
  }

  function trySkip(){
    const now = Date.now();
    if (now - state.lastAction < THROTTLE) return false;

    // Close banner overlays if present
    if (now - state.lastClose > 500){
      const close = findOverlayClose();
      if (close){ burstClick(close); state.lastClose = now; }
    }

    const btn = findSkipButton();
    if (btn){
      burstClick(btn);
      state.lastAction = now;
      // quick follow-up taps for enablement race
      setTimeout(() => { const b = findSkipButton(); if (b) burstClick(b); }, 40);
      setTimeout(() => { const b = findSkipButton(); if (b) burstClick(b); }, 120);
      return true;
    }
    return false;
  }

  function detectAd(){
    const player = root();
    return !!player && (
      player.classList.contains('ad-showing') ||
      player.classList.contains('ad-interrupting') ||
      !!document.querySelector('.ytp-ad-player-overlay') ||
      !!document.querySelector('.ytp-ad-text') ||
      !!document.querySelector('.ytp-ad-skip-button') ||
      !!document.querySelector('.ytp-ad-skip-button-modern')
    );
  }

  function loop(){
    const ad = detectAd();
    send(!!ad, ad ? 'youtube: ad markers present' : '');
    if (ad) trySkip();
    setTimeout(loop, ad ? 100 : 420);
  }
  loop();

  // React immediately when the Skip container toggles visibility/enabled
  function wireObserver(){
    const r = root(); if (!r) return;
    const mo = new MutationObserver(() => { if (state.isAd) trySkip(); });
    try { mo.observe(r, { subtree:true, childList:true, attributes:true, attributeFilter:['class','style','hidden','disabled','aria-label'] }); } catch(e){}
  }
  wireObserver();
})();