/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */

(function(){
  if (window.top !== window) return; // only top frame
  if (window.__admuteNetflixLoaded) return; window.__admuteNetflixLoaded = true;

  let MODE = 'strict'; // or 'balanced'
  chrome.storage.local.get({ admute_nx_mode: 'strict' }, (r) => { MODE = r.admute_nx_mode; });
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'NX_MODE' && (msg.mode === 'strict' || msg.mode === 'balanced')) {
      MODE = msg.mode; console.debug('[Ad Mute][Netflix] mode:', MODE);
    }
  });

  function normText(x){ if (x==null) return ''; if (typeof x==='string') return x;
    if (typeof x==='number'||typeof x==='boolean') return String(x);
    if (typeof x==='object' && typeof x.baseVal==='string') return x.baseVal; try { return String(x);} catch(e){return '';} }
  function inViewport(r, vw, vh){ if(!r) return false; return r.bottom>0 && r.right>0 && r.left<vw && r.top<vh; }
  function isVisible(el){ if (!el) return false; const st = getComputedStyle(el);
    if (st.display==='none'||st.visibility==='hidden'||+st.opacity===0) return false;
    const rects=el.getClientRects(); if(!(rects && rects.length)) return false; const r = rects[0]; const vw = Math.max(document.documentElement.clientWidth, innerWidth||0); const vh = Math.max(document.documentElement.clientHeight, innerHeight||0);
    return inViewport(r, vw, vh); }
  function rect(el){ try { return el.getBoundingClientRect(); } catch(e){ return {x:0,y:0,width:0,height:0}; } }
  function walkDeep(root, visit, cap=6000){
    const stack=[root]; let n,c=0;
    while(stack.length && c<cap){ n=stack.pop(); if(!n) continue; c++; visit(n);
      if(n.shadowRoot) stack.push(n.shadowRoot);
      const ch=n.children||n.childNodes; if(ch&&ch.length){ for(let i=ch.length-1;i>=0;i--) stack.push(ch[i]); } }
  }
  function deepText(n){ return normText(n && (n.innerText||n.textContent) || ''); }

  const RX_AD_TOKEN = /(^|[\s•:–—-])ad($|[\s•:–—-])/i;
  const RX_AD_WORD = /^ad$/i;
  const RX_TIMER_MMSS = /\b\d{1,2}:\d{2}\b/;
  function hasSecondsOnlyTimer(s){
    const m = s.match(/(?:^|[•\s])(\d{1,3})(?:\s*sec(?:onds?)?)?(?:$|[•\s])/i);
    if (!m) return false;
    const n = parseInt(m[1], 10);
    return n > 0 && n <= 600;
  }
  function siblingHasDigits(el){
    const p = el.parentElement; if (!p) return false;
    for (const child of Array.from(p.childNodes)){
      if (child === el) continue;
      const txt = (child.nodeType === 3 ? String(child.nodeValue||'') : (child.nodeType===1 ? (child.innerText||child.textContent||'') : '')).trim();
      if (!txt) continue;
      if (/^\d{1,3}$/.test(txt)) { const n = parseInt(txt,10); if (n>0 && n<=600) return true; }
    }
    return false;
  }
  const RX_AD_OF = /\bad\s+\d+\s+of\s+\d+\b/i;
  const RX_LEARN = /\blearn more\b/i;
  const RX_IGNORE = /^(audio|subtitles|cc|next episode|skip intro|back|\d+x)$/i;

  function scanForAd(root){
    const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh = Math.max(document.documentElement.clientHeight, innerHeight||0);
    let found=false, reason='';

    walkDeep(root, (el)=>{
      if(found) return;
      if(el.nodeType!==1 || !isVisible(el)) return;
      const t = deepText(el).trim();
      if(!t || RX_IGNORE.test(t)) return;

      // "Ad N of M" strong signal
      if (RX_AD_OF.test(t)) {
        const b = rect(el);
        const left = b.x < vw*0.50, right = b.x > vw*0.50;
        const top = b.y < vh*0.30, bottom = b.y > vh*0.58;
        if (MODE === 'strict') {
          if ((left && top) || (left && bottom) || (right && top)) {
            found=true; reason='netflix(strict): Ad N of M (corner)';
          }
        } else {
          found=true; reason='netflix(bal): Ad N of M';
        }
        if (found) return;
      }

      // "Ad" + buddy (timer/seconds/learn/N-of-M/sibling digits)
      if (RX_AD_WORD.test(t) || RX_AD_TOKEN.test(t)){
        const p = el.parentElement || el;
        const pt = deepText(p);
        const b = rect(p);
        const left = b.x < vw*0.50, right = b.x > vw*0.50;
        const top = b.y < vh*0.30, bottom = b.y > vh*0.58;
        const hasBuddy = RX_TIMER_MMSS.test(pt) || hasSecondsOnlyTimer(pt) || RX_LEARN.test(pt) || RX_AD_OF.test(pt) || siblingHasDigits(el);

        if (MODE === 'strict') {
          if (hasBuddy && ((left && top) || (left && bottom) || (right && top))) {
            found=true; reason='netflix(strict): Ad + buddy (corner)';
          }
        } else {
          if (hasBuddy) { found=true; reason='netflix(bal): Ad + buddy'; }
        }
      }
    });

    return { isAd: found, reason };
  }

  const state = { isAd:false, lastChange:0, timer:0, lastTick:0, misses:0, streakAd:0, streakContent:0, coolUntil:0 };
  const FAST=100, NORMAL=240;
  function schedule(ms){ clearTimeout(state.timer); state.timer = setTimeout(tick, ms); }
  function tickSoon(){ const now=Date.now(); if(now-state.lastTick>50){ clearTimeout(state.timer); requestAnimationFrame(tick); } }
  document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) tickSoon(); });

  function getRoot(){
    const v = document.querySelector('video');
    if(!v) return document.body;
    const r = v.closest('[role="application"],[data-uia*="player"],[class*="player"]');
    return r || v.parentElement || document.body;
  }

  function send(isAd, meta){
    if(state.isAd===isAd) return;
    state.isAd=isAd; state.lastChange=Date.now();
    if(!isAd){ state.coolUntil = Date.now() + 1200; } // cool-off after ad ends
    chrome.runtime.sendMessage({ type:'AD_STATE', isAd, reason: meta && meta.reason });
    if(meta && meta.reason) console.debug('[Ad Mute][Netflix] reason:', meta.reason);
  }

  function tick(){
    try {
      state.lastTick = Date.now();
      const root = getRoot();
      let meta = scanForAd(root);
      if(!meta.isAd){
        state.misses++;
        if(state.misses % 18 === 0){
          const m2 = scanForAd(document.body);
          if(m2.isAd) meta = m2;
        }
      } else state.misses = 0;
      // hysteresis: require 2 consecutive positives to turn ON, 3 consecutive negatives to turn OFF
      if (meta.isAd) { state.streakAd++; state.streakContent = 0; }
      else { state.streakContent++; state.streakAd = 0; }
      let next = state.isAd;
      if (!state.isAd) {
        if (state.streakAd >= 2) next = true; // enter ad only after 2 positive reads
      } else {
        if (state.streakContent >= 3) next = false; // exit ad after 3 non-ad reads
      }
      // cool-off: ignore ad blips shortly after ad ends
      if (!state.isAd && Date.now() < state.coolUntil && next) {
        next = false;
      }
      if (next !== state.isAd) send(next, meta);
      const since = Date.now() - state.lastChange;
      schedule((meta.isAd || since < 1800) ? FAST : NORMAL);
    } catch(e){ schedule(300); }
  }
  tick();

  let mo = new MutationObserver(()=>tickSoon());
  function watchRoot(){ const r=getRoot(); try{ mo.disconnect(); mo.observe(r, { subtree:true, childList:true, characterData:true }); }catch(e){} }
  watchRoot();

  (function hookVideo(){
    const v=document.querySelector('video');
    if(!v){ setTimeout(hookVideo, 800); return; }
    v.addEventListener('timeupdate', tickSoon, {passive:true});
    v.addEventListener('seeking', tickSoon, {passive:true});
    v.addEventListener('ratechange', tickSoon, {passive:true});
    setInterval(watchRoot, 2000);
  })();
})();
