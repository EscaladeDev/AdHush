/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */

(function() {
  if (window.top !== window) return; // only top frame
  if (window.__admuteOverlayLoaded) return;
  window.__admuteOverlayLoaded = true;

  function el(html) { const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild; }
  const isNetflix = /(^|\.)netflix\.com$/.test(location.hostname);

  const root = el(`
    <div id="admute-overlay" style="display:none">
      <div class="bar">
        <button class="pill mute"   title="Force mute (treat as Ad)">Mute</button>
        <button class="pill unmute" title="Force unmute (treat as Content)">Unmute</button>
        <button class="pill auto"   title="Return to automatic detection">Auto</button>
        <span class="signal" id="ovl-signal">—</span>
        ${isNetflix ? '<button class="pill mode" id="nx-mode-btn" title="Toggle Strict/Balanced for Netflix">Strict</button>' : ''}
        <button class="close" title="Close">✕</button>
      </div>
    </div>
  `);
  document.documentElement.appendChild(root);

  const qs = (s) => root.querySelector(s);
  function setVisible(v) { root.style.display = v ? 'block' : 'none'; }

  function setActiveMode(force){
    const btnMute = root.querySelector('.pill.mute');
    const btnUnmute = root.querySelector('.pill.unmute');
    const btnAuto = root.querySelector('.pill.auto');
    [btnMute, btnUnmute, btnAuto].forEach(b => b.classList.remove('active'));
    if (force === true){
      btnMute.classList.add('active');
      if (btnAuto) btnAuto.textContent = 'Manual';
    } else if (force === false){
      btnUnmute.classList.add('active');
      if (btnAuto) btnAuto.textContent = 'Manual';
    } else {
      btnAuto.classList.add('active');
      if (btnAuto) btnAuto.textContent = 'Auto';
    }
  }

  function setFromPayload(res){
    if (!res) return;
    const eff = 'Now: ' + (res.effective ? 'AD' : 'content');
    const mut = 'Muted: ' + (res.muted ? 'yes' : 'no');
    const reason = (res.reason ? (' — ' + res.reason) : '');
    const el = qs('#ovl-signal'); if (el) el.textContent = eff + '  •  ' + mut + reason;
    setActiveMode(res.force);
  }

  function refresh() {
    chrome.runtime.sendMessage({ type: "GET_STATE" }, (res) => {
      if (!res?.ok) return;
      setFromPayload(res);
    });
  }

  root.querySelector('.pill.mute').addEventListener('click', () => chrome.runtime.sendMessage({ type: "FORCE_STATE", force: true }, refresh));
  root.querySelector('.pill.unmute').addEventListener('click', () => chrome.runtime.sendMessage({ type: "FORCE_STATE", force: false }, refresh));
  root.querySelector('.pill.auto').addEventListener('click', () => chrome.runtime.sendMessage({ type: "FORCE_STATE", force: null }, refresh));
  root.querySelector('.close').addEventListener('click', () => setVisible(false));

  if (isNetflix) {
    chrome.storage.local.get({ admute_nx_mode: 'strict' }, (r) => {
      const btn = qs('#nx-mode-btn');
      if (!btn) return;
      btn.textContent = (r.admute_nx_mode === 'balanced') ? 'Balanced' : 'Strict';
      btn.addEventListener('click', () => {
        chrome.storage.local.get({ admute_nx_mode: 'strict' }, (r2) => {
          const next = (r2.admute_nx_mode === 'balanced') ? 'strict' : 'balanced';
          chrome.storage.local.set({ admute_nx_mode: next }, () => {
            btn.textContent = (next === 'balanced') ? 'Balanced' : 'Strict';
            chrome.runtime.sendMessage({ type: 'NX_MODE', mode: next });
          });
        });
      });
    });
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'STATE_PUSH') setFromPayload(msg);
    else if (msg?.type === 'OVERLAY_TOGGLE') {
      setVisible(root.style.display === 'none');
      if (root.style.display !== 'none') refresh();
    }
  });

  setTimeout(() => { setVisible(true); refresh(); }, 600);
})();
