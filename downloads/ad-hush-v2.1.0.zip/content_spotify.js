
// Spotify Web: heuristic detector
(function(){
  'use strict';
  if (window.__ADMUTE_SP__) return; window.__ADMUTE_SP__ = true;

  function ping(){ try{ chrome.runtime.sendMessage({ type:'PAGE_PING', site:'spotify' }); }catch{} }
  function report(isAdState, reason){ try{ chrome.runtime.sendMessage({ type:'PAGE_STATE', isAd:!!isAdState, reason, site:'spotify' }); }catch{} }
  ping();

  function looksLikeAd(){
    const cand = Array.from(document.querySelectorAll('[data-testid],div,span'))
      .slice(0, 800)
      .find(n => {
        const t = ((n.getAttribute('data-testid')||'') + ' ' + (n.textContent||'')).toLowerCase();
        return t.includes('advert') || t.includes('advertisement');
      });
    return !!cand;
  }

  let t=0;
  function schedule(ms){ clearTimeout(t); t=setTimeout(tick, ms||600); }
  function tick(){
    clearTimeout(t);
    const ad = looksLikeAd();
    report(ad, ad ? 'spotify: Advertisement' : 'spotify: content');
    schedule(ad ? 320 : 1200);
  }
  tick();
})();
