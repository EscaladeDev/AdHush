
// YouTube: detection + auto-skip (non-intrusive)
(function(){
  'use strict';
  if (window.__ADMUTE_YT__) return; window.__ADMUTE_YT__ = true;

  const q = (s)=>document.querySelector(s);
  const player = ()=> q('.html5-video-player');
  const isAd = ()=> !!(player() && player().classList.contains('ad-showing'));

  function ping(){ try{ chrome.runtime.sendMessage({ type:'PAGE_PING', site:'youtube' }); }catch{} }
  function report(isAdState, reason){ try{ chrome.runtime.sendMessage({ type:'PAGE_STATE', isAd:!!isAdState, reason, site:'youtube' }); }catch{} }
  ping();

  let lastClick = 0;
  const CLICK_DEBOUNCE = 900;
  function safeClick(el){
    const now = Date.now();
    if (now - lastClick < CLICK_DEBOUNCE) return;
    lastClick = now;
    try {
      el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true }));
      el.click();
    } catch {}
  }

  let t=0;
  function schedule(ms){ clearTimeout(t); t=setTimeout(tick, ms||400); }
  function tick(){
    clearTimeout(t);
    const ad = isAd();
    report(ad, ad ? 'youtube: ad-showing' : 'youtube: content');

    if (ad){
      const overlayClose = q('.ytp-ad-overlay-close-button');
      if (overlayClose && overlayClose.offsetParent !== null) safeClick(overlayClose);
      const skip = q('.ytp-ad-skip-button.ytp-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-modern .ytp-button, .ytp-skip-ad-button');
      if (skip && skip.offsetParent !== null) safeClick(skip);
      schedule(150);
    } else {
      schedule(1000);
    }
  }

  function bind(){
    const p = player();
    if(!p){ setTimeout(bind, 800); return; }
    try { new MutationObserver(()=>schedule(50)).observe(p, { attributes:true, attributeFilter:['class'] }); } catch {}
    try {
      const app = document.querySelector('ytd-app') || document.documentElement;
      new MutationObserver(()=>schedule(200)).observe(app, { childList:true, subtree:true });
    } catch {}
    tick();
  }
  bind();
})();
