
// Disney+: heuristic detector
(function(){
  'use strict';
  if (window.__ADMUTE_DP__) return; window.__ADMUTE_DP__ = true;

  function ping(){ try{ chrome.runtime.sendMessage({ type:'PAGE_PING', site:'disneyplus' }); }catch{} }
  function report(isAdState, reason){ try{ chrome.runtime.sendMessage({ type:'PAGE_STATE', isAd:!!isAdState, reason, site:'disneyplus' }); }catch{} }
  ping();

  function looksLikeAd(){
    const el = Array.from(document.querySelectorAll('div,span'))
      .slice(0, 600)
      .find(n => n && n.textContent && /^\s*Ad\b/i.test(n.textContent));
    return !!el;
  }

  let t=0;
  function schedule(ms){ clearTimeout(t); t=setTimeout(tick, ms||400); }
  function tick(){
    clearTimeout(t);
    const ad = looksLikeAd();
    report(ad, ad ? 'disney+: badge' : 'disney+: content');
    schedule(ad ? 220 : 1000);
  }
  tick();
})();
