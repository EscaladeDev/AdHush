
// Netflix: heuristic detector
(function(){
  'use strict';
  if (window.__ADMUTE_NF__) return; window.__ADMUTE_NF__ = true;

  function ping(){ try{ chrome.runtime.sendMessage({ type:'PAGE_PING', site:'netflix' }); }catch{} }
  function report(isAdState, reason){ try{ chrome.runtime.sendMessage({ type:'PAGE_STATE', isAd:!!isAdState, reason, site:'netflix' }); }catch{} }
  ping();

  function looksLikeAd(){
    const badge = Array.from(document.querySelectorAll('div,span'))
      .slice(0, 600)
      .find(n => n && n.textContent && /^\s*Ad(\s+\d|$)/i.test(n.textContent));
    if (badge) return true;
    const attr = document.querySelector('[data-uia*="ad"]');
    return !!attr;
  }

  let t=0;
  function schedule(ms){ clearTimeout(t); t=setTimeout(tick, ms||400); }
  function tick(){
    clearTimeout(t);
    const ad = looksLikeAd();
    report(ad, ad ? 'netflix: ad-badge' : 'netflix: content');
    schedule(ad ? 220 : 1000);
  }
  tick();
})();
