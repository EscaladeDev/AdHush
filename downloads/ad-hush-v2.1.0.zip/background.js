'use strict';
// AdHush — MV3 service worker (mute logic + overlay toggle)
const STATE = new Map(); // tabId -> { isAd, force, muted, reason, site }

function computeMuted(s) {
  if (!s) return false;
  if (s.force === true)  return true;   // manual: Mute
  if (s.force === false) return false;  // manual: Unmute
  return !!s.isAd;                      // auto
}

async function applyMute(tabId, muted) {
  try { await chrome.tabs.update(tabId, { muted }); } catch {}
}

function pushState(tabId) {
  const s = STATE.get(tabId);
  if (!s) return;
  try { chrome.tabs.sendMessage(tabId, { type:'STATE_PUSH', ok:true, ...s }); } catch {}
}

chrome.runtime.onInstalled.addListener(() => {
  try {
    chrome.contextMenus.create({
      id: 'adhush-toggle-overlay',
      title: 'AdHush: Toggle overlay',
      contexts: ['all']
    });
  } catch {}
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'adhush-toggle-overlay' && tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type:'OVERLAY_TOGGLE' });
  }
});

chrome.commands?.onCommand.addListener(async (command) => {
  if (command !== 'toggle-overlay') return;
  try {
    const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type:'OVERLAY_TOGGLE' });
  } catch {}
});

chrome.tabs.onRemoved.addListener(tabId => { STATE.delete(tabId); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  if (!tabId) { sendResponse?.({ ok:false }); return; }

  const s = STATE.get(tabId) || { isAd:false, force:null, muted:false, reason:'', site:'' };

  if (msg.type === 'PAGE_PING') {
    s.site = msg.site || s.site;
    STATE.set(tabId, s);
    sendResponse?.({ ok:true });
    return;
  }

  if (msg.type === 'PAGE_STATE') {
    s.isAd = !!msg.isAd;
    s.reason = msg.reason || '';
    s.muted = computeMuted(s);
    STATE.set(tabId, s);
    applyMute(tabId, s.muted);
    pushState(tabId);
    sendResponse?.({ ok:true });
    return;
  }

  if (msg.type === 'GET_STATE') {
    STATE.set(tabId, s);
    sendResponse?.({ ok:true, ...s });
    return;
  }

  if (msg.type === 'FORCE_STATE') {
    s.force = (msg.force === true) ? true : (msg.force === false) ? false : null;
    s.muted = computeMuted(s);
    STATE.set(tabId, s);
    applyMute(tabId, s.muted);
    pushState(tabId);
    sendResponse?.({ ok:true, ...s });
    return;
  }

  if (msg.type === 'SYNC_NOW' || msg.type === 'NX_MODE' || msg.type === 'FAST_WINDOW') {
    sendResponse?.({ ok:true });
    return;
  }

  sendResponse?.({ ok:false });
});
