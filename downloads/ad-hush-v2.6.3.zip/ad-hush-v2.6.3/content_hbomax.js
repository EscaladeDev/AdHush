/* AdHush | © 2025 Escalade. All rights reserved. Proprietary — see EULA.txt. */

try { chrome.runtime.sendMessage({type:'PAGE_PING', site:'hbomax'}); } catch(e) {}

(function(){
  'use strict';
  if (window.top !== window) return;
  if (window.__adhushHBOMaxLoaded) return; window.__adhushHBOMaxLoaded = true;

  // --- utils ---
  function norm(x){ if(x==null) return ''; if(typeof x==='string') return x;
    if(typeof x==='number'||typeof x==='boolean') return String(x);
    if(typeof x==='object' && typeof x.baseVal==='string') return x.baseVal;
    try { return String(x); } catch { return ''; } }
  function inViewport(r,vw,vh){ return r && r.bottom>0 && r.right>0 && r.left<vw && r.top<vh; }
  function isVis(el){
    if(!el) return false;
    const st = getComputedStyle(el);
    if (st.display==='none'||st.visibility==='hidden'||+st.opacity===0) return false;
    const rs = el.getClientRects(); if(!(rs&&rs.length)) return false;
    const r = rs[0];
    const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh = Math.max(document.documentElement.clientHeight, innerHeight||0);
    return inViewport(r,vw,vh);
  }
  function txt(n){ return norm(n && (n.innerText||n.textContent) || ''); }
  function walk(root, fn, cap=6000){
    const st=[root]; let n,c=0;
    while((n=st.pop()) && c++<cap){
      if(fn(n)===false) break;
      const ch=n && n.childNodes; if(ch && ch.length){ for(let i=ch.length-1;i>=0;i--) st.push(ch[i]); }
    }
  }

  const RX_WORD=/^ad$/i;
  const RX_AD=/(\bad\b|\bad\s+\d+\s+of\s+\d+\b)/i; // "Ad" or "Ad 1 of 2"
  const RX_MMSS=/\b\d{1,2}:\d{2}\b/;

  function likelyChip(el){
    // HBO/Max places an "Ad 1 of 2 0:24" chip near the top left of the player.
    // We consider small elements in the top 30% of the viewport.
    try{
      const r = el.getBoundingClientRect();
      const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
      const vh = Math.max(document.documentElement.clientHeight, innerHeight||0);
      if (r.width>0 && r.height>0 && r.height<120 && r.top<(vh*0.32) && r.left<(vw*0.6)) return true;
    }catch{}
    return false;
  }

  function playerRoot(){
    // prefer the video player container if present
    const sel = [
      '[data-testid*="player"]',
      '[class*="player"]',
      '[role="main"] video, video'
    ];
    for (const s of sel){
      const el = document.querySelector(s);
      if (el){ return el.closest('*') || el; }
    }
    return document.body;
  }

  function scan(root){
    const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh = Math.max(document.documentElement.clientHeight, innerHeight||0);
    let found=false, reason='', mmssSeen=false;

    walk(root, (el)=>{
      if(found) return false;
      if(el.nodeType!==1) return;

      if(!isVis(el)) return;
      const t = txt(el).trim();
      if(!t) return;

      // direct "Ad 1 of 2 0:24" style
      if ((RX_WORD.test(t) || RX_AD.test(t) || /ad\s*\d/i.test(t)) && (RX_MMSS.test(t) || likelyChip(el))){
        found=true; reason='hbomax: ad chip';
        return false;
      }

      // split elements: parent contains "Ad 1 of 2", sibling contains "0:24"
      if (likelyChip(el) && (RX_WORD.test(t) || RX_AD.test(t))){
        // look nearby for a mm:ss
        const p = el.parentElement;
        if(p){
          const tt = txt(p);
          if(RX_MMSS.test(tt)){ found=true; reason='hbomax: chip+parent timer'; return false; }
          // siblings
          for(const sib of (p.childNodes||[])){
            if(sib!==el && sib.nodeType===1){
              const st = txt(sib);
              if(RX_MMSS.test(st)){ found=true; reason='hbomax: chip+sibling timer'; return false; }
            }
          }
        }
      }

      // Single visible countdown with "Ad" nearby up the tree
      if(!RX_MMSS.test(t)) return;
      // check ancestors for 'Ad'
      let cur=el;
      for(let k=0;k<3;k++){
        cur = cur?.parentElement;
        if(!cur) break;
        const pt = txt(cur);
        if(RX_AD.test(pt) || RX_WORD.test(pt)){
          if(likelyChip(cur)){ found=true; reason='hbomax: parent has Ad'; return false; }
        }
      }
    });

    return {found, reason: reason||''};
  }

  const state = { isAd:false };
  function send(isAd, reason){
    if(state.isAd===isAd) return;
    state.isAd=isAd;
    try{ chrome.runtime.sendMessage({type:'AD_STATE', isAd, reason}); }catch{}
  }

  // cadence + observer
  let fastUntil=0, timer=null;
  function bumpFast(ms=2400){ fastUntil=Date.now()+ms; }
  function cadence(){ return Date.now() < fastUntil ? 120 : 850; }
  function schedule(ms){ clearTimeout(timer); timer=setTimeout(run, ms); }
  function run(){
    const root = playerRoot() || document.body;
    const r = scan(root);
    send(!!r.found, r.reason||'');
    schedule(cadence());
  }

  const ro = new MutationObserver(()=>{ bumpFast(); schedule(60); });
  try{ ro.observe(document, {subtree:true, childList:true, attributes:true, characterData:true}); }catch{}
  ['visibilitychange','popstate','hashchange','pageshow','keydown','keyup','click'].forEach(ev=>{
    addEventListener(ev, ()=>{ bumpFast(); schedule(60); }, {passive:true});
  });

  run();
})();
