/* AdHush | © 2025 Kaboombooo. All rights reserved. Proprietary — see EULA.txt. */

(function(){try{chrome.runtime.sendMessage({type:'PAGE_PING',site:'primevideo'});}catch{}})();