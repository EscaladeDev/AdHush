/* AdHush | © 2025 Kaboombooo. All rights reserved. Proprietary — see EULA.txt.
*/

try { chrome.runtime.sendMessage({type:'PAGE_PING', site:'primevideo'}); } catch(e) {}

(function(){
  'use strict';
  if (window.top !== window) return;
  if (window.__adhushPrime_hotfix) return; window.__adhushPrime_hotfix = true;

  // ---- Tunables: favor responsiveness without reintroducing FP ----
  const FAST_MS = 60;                 // faster cadence during "fast" mode
  const SLOW_MS = 800;                // Slightly faster idle scan

  const DEBOUNCE_MS = 30;             // quicker reaction to DOM changes
  const LATCH_MS = 900;               // Minimum time to hold mute once triggered

  // EXIT THRESHOLDS
  const EXIT_CLEAN_SCANS = 3;         // How many clean scans before unmute
  const EXIT_FAST_MS = 700;           // Standard unmute speed (natural end)
  const EXIT_FORCED_MS = 1400;        // Max time to wait if we think an ad *should* be playing (fixes "Skip Ad")
  const TOUCHDOWN_MS = 350;           // Very fast unmute if timer was < 2s

  const COUNTDOWN_TTL_MS = 4800;
  const MIN_DROP = 5;

  const RUNWAY_PAD_MS = 520;

  // Scan limits: allow deeper scans while in FAST mode only
  const MAX_HOSTS_BASE = 24, MAX_NODES_PER_HOST_BASE = 140, MAX_GLOBAL_NODES_BASE = 320;
  const MAX_HOSTS_FAST = 36, MAX_NODES_PER_HOST_FAST = 180, MAX_GLOBAL_NODES_FAST = 520;

  // ---- Regexes ----
  const RX_MMSS = /\b([0-5]?\d):([0-5]\d)\b/;
  const RX_AD   = /(^|[\s•:–—-])ad($|[\s•:–—-])/i;
  const RX_NO   = /\b(up\s*next|next episode|autoplay|intro|recap|preview|trailer|x[-\s]?ray)\b/i;
  const RX_CTA  = /\b(go ad ?free|why (?:am i seeing|this) ad|skip ads?)\b/i;

  // ---- Utils ----
  const T = (el)=> el ? (el.innerText || el.textContent || '').trim() : '';
  const pseudo = (el)=>{
    try{
      const b = getComputedStyle(el, '::before').content;
      const a = getComputedStyle(el, '::after').content;
      const s = [b,a].filter(x=>x && x!=='none' && x!=='normal').map(x=>x.replace(/^["']|["']$/g,'')).join(' ').trim();
      return s;
    }catch{ return ''; }
  };
  const V = (el)=>{
    if (!el || !el.isConnected) return false;
    const cs = getComputedStyle(el);
    if (cs.display==='none'||cs.visibility==='hidden'||+cs.opacity===0) return false;
    const r = el.getBoundingClientRect();
    return r.width>6 && r.height>6 && r.bottom>0 && r.right>0 &&
           r.left<(innerWidth||1) && r.top<(innerHeight||1);
  };
  const inTL = (el)=>{
    // tighter TL window reduces noise; keeps detection focused
    const r=el.getBoundingClientRect();
    const vw=Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh=Math.max(document.documentElement.clientHeight, innerHeight||0);
    return r.top>=0 && r.top<vh*0.25 && r.left>=0 && r.left<vw*0.40;
  };
  const aria = (el)=> (el && el.getAttribute && (el.getAttribute('aria-label')||'')) || '';
  const together = (el)=> (T(el)+' '+aria(el)+' '+pseudo(el)).trim();
  const excluded=(el)=>{
    let n=el; for(let i=0;i<6 && n;i++,n=n.parentElement){
      const s=together(n); if (s && RX_NO.test(s)) return true;
    } return false;
  };

  function bigVideo(){
    let best=null, area=0;
    for (const v of document.querySelectorAll('video')){
      const r=v.getBoundingClientRect(), a=r.width*r.height;
      if (a>area){ best=v; area=a; }
    }
    return best;
  }
  function playerRoot(){
    const v=bigVideo(); if(!v) return null;
    return v.closest('.atvwebplayersdk-root, .atvwebplayersdk-player, .webPlayerUIContainer, #dv-web-player') || document.body;
  }

  // ---- Adaptive cadence, immediate scans, and event-driven bumps ----
  let fastUntil=0, timer=null, pending=false, rafPending=false;
  function inFast(){ return Date.now() < fastUntil; }
  function bumpFast(ms=4200){ fastUntil = Math.max(fastUntil, Date.now()+ms); } // extend, don't overwrite
  function cadence(){ return inFast() ? FAST_MS : SLOW_MS; }
  function schedule(ms){ clearTimeout(timer); timer=setTimeout(scan, ms); }
  function scheduleFast(){ bumpFast(); schedule(FAST_MS); }

  // Allow immediate reaction on hot events without waiting for timeout
  function scanNow(){
    if (rafPending) return; // coalesce to next frame for UI stability
    rafPending = true;
    requestAnimationFrame(()=>{ rafPending=false; pending=false; const next=step(); publish(next); schedule(cadence()); });
  }

  // countdown memory + runway
  let lastDrop = { sec:null, at:0 };
  let runwayUntil = 0;
  let lastSeenSec = null;
  let lastEvidenceAt = 0;

  function secFromMatch(m){
    const mi=+m[1], se=+m[2];
    if (Number.isNaN(mi) || Number.isNaN(se)) return NaN;
    return mi*60 + se;
  }
  function noteCountdown(sec){
    lastSeenSec = sec;
    const end = Date.now() + sec*1000 + RUNWAY_PAD_MS;
    if (end > runwayUntil) runwayUntil = end;
  }
  function droppedFromSec(cur){
    const now=Date.now();
    if (now-lastDrop.at>COUNTDOWN_TTL_MS || lastDrop.sec==null){ lastDrop={sec:cur,at:now}; noteCountdown(cur); return false; }
    const d=lastDrop.sec-cur; lastDrop={sec:cur,at:now};
    if (d>=MIN_DROP && d<=60){ noteCountdown(cur); return true; }
    return false;
  }

  // ---- Finders (conservative semantics, faster path) ----
  function analyzeNode(el){
    const self = together(el);
    if (!self || self.length>80) return null;

    const parentText = el.parentElement ? together(el.parentElement) : '';
    const text = (self + ' ' + parentText).trim();

    let m = text.match(RX_MMSS);
    const hasAdWord = RX_AD.test(text);
    const hasCta = RX_CTA.test(text);

    if (!m && hasAdWord){
      // explicit "Ad" without timer: treat as strong
      return { hasTimer:false, hasAdWord:true, hasCta, sec:null, score:3, reason:'explicit Ad' };
    }

    if (!m) return null;

    const sec = secFromMatch(m);
    if (!Number.isFinite(sec)) return null;

    return {
      hasTimer:true,
      hasAdWord,
      hasCta,
      sec,
      score: hasAdWord ? 3 : (hasCta ? 2 : 1),
      reason: hasAdWord ? 'explicit Ad mm:ss' : (hasCta ? 'timer + CTA' : 'timer-only')
    };
  }

  function eachNodeLimited(root, visit){
    const fast = inFast();
    const MAX_HOSTS = fast ? MAX_HOSTS_FAST : MAX_HOSTS_BASE;
    const MAX_NODES_PER_HOST = fast ? MAX_NODES_PER_HOST_FAST : MAX_NODES_PER_HOST_BASE;
    let hosts=0, seen=0; const st=[root];
    while(st.length){
      const n=st.pop(); if(!n || n.nodeType!==1) continue;
      visit(n);
      seen++; if(seen > MAX_HOSTS*MAX_NODES_PER_HOST) break;
      const ch=n.children; if(ch && ch.length){
        const lim=Math.min(ch.length, MAX_NODES_PER_HOST);
        for(let i=0;i<lim;i++) st.push(ch[i]);
      }
      if(n.shadowRoot && ++hosts<=MAX_HOSTS){
        const kids=n.shadowRoot.children||[];
        const lim2=Math.min(kids.length, MAX_NODES_PER_HOST);
        for(let i=0;i<lim2;i++) st.push(kids[i]);
      }
    }
  }

  function findBadgeIn(root){
    let best=null;
    eachNodeLimited(root, (el)=>{
      if (!V(el) || !inTL(el) || excluded(el)) return;
      const res = analyzeNode(el);
      if (!res) return;
      if (res.score===3){ best=res; return; }
      if (!best || res.score > best.score) best=res;
    });
    return best;
  }
  function findBadgeGlobal(){
    const fast = inFast();
    const MAX_GLOBAL_NODES = fast ? MAX_GLOBAL_NODES_FAST : MAX_GLOBAL_NODES_BASE;
    const nodes=document.querySelectorAll('span,div,button,a'); let checked=0, best=null;
    for(const el of nodes){
      if(++checked>MAX_GLOBAL_NODES) break;
      if(!V(el) || !inTL(el) || excluded(el)) continue;
      const res = analyzeNode(el);
      if (!res) continue;
      if (res.score===3){ best=res; break; }
      if (!best || res.score > best.score) best=res;
    }
    return best;
  }
  function cheapHints(){
    const r=playerRoot(); if(!r) return false;
    const s=together(r); return !!(s && RX_CTA.test(s));
  }

  // ---- State + logic ----
  let state={ isAd:false, reason:'content' }, latchUntil=0, cleanScans=0;

  function step(){
    const root=playerRoot();
    let badge = root ? findBadgeIn(root) : null;
    if(!badge) badge = findBadgeGlobal();

    let evidence=false;
    let strong=false;

    if (badge){
      if (badge.hasAdWord){
        evidence = true; strong = true;
      } else if (badge.hasTimer && (badge.hasCta || cheapHints())){
        // faster confirm: if we have timer+CTA, try to observe a drop quickly
        if (droppedFromSec(badge.sec)) {
          evidence = true;
        } else {
          // aggressive fast-mode bump & immediate re-scan to catch the next tick
          bumpFast(5200);
          setTimeout(scanNow, 140);
        }
      }
      if (badge.hasTimer) noteCountdown(badge.sec);
    }

    if (evidence){
      lastEvidenceAt = Date.now();
      if (strong) latchUntil = lastEvidenceAt + LATCH_MS;
    }

    const onRunway = Date.now() < runwayUntil;
    const latched = (Date.now() < latchUntil);

    let next = state.isAd;

    if (!state.isAd){
      // Transition TO Ad
      if (evidence || (strong && onRunway)){
        next = true; cleanScans=0;
      }
    } else {
      // Transition TO Content (Exit Logic)
      const noEvFor = Date.now() - lastEvidenceAt;
      const nearTouchdown = (lastSeenSec != null && lastSeenSec <= 2);

      if (evidence) {
        // Still seeing ad evidence, stay muted
        next = true; cleanScans=0;
      } else if (latched) {
        // Just started muting, hold it to prevent start-flicker
        next = true;
      } else {
        // Check exit conditions
        cleanScans++;

        // Determining the max tolerance for missing evidence:
        // 1. If we are near touchdown (timer < 2s), exit very fast.
        // 2. If we are 'onRunway' (timer says ad is playing), wait a bit longer (1.4s)
        //    to handle buffering or black screen between ads.
        //    BUT, do not wait forever (fixes "Skip Ad" bug).
        // 3. Normal exit (0.7s)
        
        let exitThreshold = EXIT_FAST_MS;
        if (nearTouchdown) exitThreshold = TOUCHDOWN_MS;
        else if (onRunway) exitThreshold = EXIT_FORCED_MS; 

        if (cleanScans >= EXIT_CLEAN_SCANS || noEvFor >= exitThreshold){
          next = false; 
          cleanScans = 0;
          // Clear runway if we forced an exit (so we don't accidentally re-enter)
          runwayUntil = 0; 
        }
      }
    }

    return next;
  }

  function publish(isAd){
    if (state.isAd === isAd) return;
    state = { isAd, reason: isAd ? 'ad' : 'content' };
    try{ chrome.runtime.sendMessage({ type:'AD_STATE', isAd: state.isAd, reason: state.reason }); }catch{}
    document.dispatchEvent(new CustomEvent('adhush:state',{ detail:{ site:'primevideo', isAd: state.isAd, reason: state.reason, ts:Date.now() }}));
    try{ window.postMessage({ source:'adhush', site:'primevideo', type:'state', isAd: state.isAd, reason: state.reason, ts:Date.now() }, '*'); }catch{}
  }

  function scan(){ pending=false; const next = step(); publish(next); schedule(cadence()); }
  function debounced(){
    if(pending) return;
    pending=true;
    // micro-wait to batch rapid mutations but stay responsive
    setTimeout(()=>{ if (inFast()) scanNow(); else scan(); }, DEBOUNCE_MS);
  }

  // ---- Observers & event hooks (responsiveness boosters) ----
  let mo, ro;
  function watch(){
    const r=playerRoot(); try{ if(mo) mo.disconnect(); }catch{}
    if(!r) return;
    mo=new MutationObserver(debounced);
    try{
      mo.observe(r, { subtree:true, childList:true, attributes:true, characterData:true, attributeFilter:['class','style','hidden','aria-label','role'] });
    }catch{}
    // Resize changes often accompany overlay swaps; react quickly
    try{
      if (ro) ro.disconnect();
      ro = new ResizeObserver(()=>{ bumpFast(); scanNow(); });
      ro.observe(r);
    }catch{}
  }

  // Hook relevant video events to jump into fast mode and scan immediately
  function hookVideoEvents(){
    const v = bigVideo(); if(!v) return;
    const bump = ()=>{ bumpFast(5000); scanNow(); };
    const touch = ()=>{ bumpFast(6000); scanNow(); };
    ['play','pause','seeking','seeked','ratechange','loadeddata','loadedmetadata','progress','waiting','timeupdate'].forEach(ev=>{
      try{ v.addEventListener(ev, ev==='timeupdate' ? bump : touch, { passive:true }); }catch{}
    });
  }

  // initial wire-up
  watch(); hookVideoEvents(); scan();

  // navigation & visibility changes
  ['popstate','pushstate','hashchange','pageshow','visibilitychange','focus'].forEach(e => addEventListener(e, ()=>{
    watch(); hookVideoEvents(); bumpFast(4500); debounced();
  }, { passive:true }));

  // history pushState hook
  (function hookHistory(){
    const o=history.pushState;
    history.pushState=function(){
      const r=o.apply(this,arguments);
      try{ dispatchEvent(new Event('pushstate')); }catch{}
      return r;
    };
  })();

  // public handle
  window.__ADHUSH_PRIMEVIDEO__ = { state:()=>state, forceScan: scanNow };
})();