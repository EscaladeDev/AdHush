/* AdHush | © 2025 Escalade. All rights reserved. Proprietary — see EULA.txt. */

(function(){try{
  if(window.top!==window) return;
  var host=(location.host||'').toLowerCase();
  var key='adhush_banner_shown@'+host;
  if(sessionStorage.getItem(key)) return;
  sessionStorage.setItem(key,'1');
  var el=document.createElement('div');
  el.textContent='AdHush is active';
  el.setAttribute('role','status');
  el.style.cssText=[
    'position:fixed','top:12px','right:12px','z-index:2147483646',
    'background:rgba(17,20,28,.92)','color:#fff','padding:10px 14px',
    'border-radius:12px','font:600 13px ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto',
    'box-shadow:0 6px 18px rgba(0,0,0,.35)','pointer-events:none',
    'opacity:0','transform:translateY(-6px)','transition:opacity .25s ease,transform .25s ease'
  ].join(';');
  document.documentElement.appendChild(el);
  requestAnimationFrame(function(){el.style.opacity='1'; el.style.transform='translateY(0)';});
  setTimeout(function(){ el.style.opacity='0'; el.style.transform='translateY(-6px)'; }, 1800);
  setTimeout(function(){ el.remove(); }, 2400);
}catch(e){}})();