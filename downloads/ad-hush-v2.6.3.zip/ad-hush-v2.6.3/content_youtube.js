/* AdHush | © 2025 Escalade. All rights reserved. Proprietary — see EULA.txt. */

try { chrome.runtime.sendMessage({type:'PAGE_PING', site:'youtube'}); } catch(e) {}

(function() {
  const state = { isAd:false, lastAction:0, lastClose:0, fastUntil:0 };
  const THROTTLE = 120;
  const send = (isAd, reason)=>{ if(state.isAd===isAd) return; state.isAd=isAd; chrome.runtime.sendMessage({type:'AD_STATE', isAd, reason}); };
  function visible(el){ if(!el) return false; const s=getComputedStyle(el); if(s.display==='none'||s.visibility==='hidden'||+s.opacity===0) return false; const rects=el.getClientRects(); if(!(rects&&rects.length)) return false; const r=rects[0]; const vw=Math.max(document.documentElement.clientWidth, innerWidth||0), vh=Math.max(document.documentElement.clientHeight, innerHeight||0); return r.width>0&&r.height>0&&r.right>0&&r.bottom>0&&r.left<vw&&r.top<vh; }
  function burstClick(target){ try{target.focus({preventScroll:true});}catch(e){} try{target.click();}catch(e){} try{const r=target.getBoundingClientRect(); const x=Math.max(1,r.left+r.width/2), y=Math.max(1,r.top+r.height/2); ['pointerdown','mousedown','mouseup','click','pointerup'].forEach(t=>{ try{ target.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,clientX:x,clientY:y})) }catch(e){} }); }catch(e){} }
  function root(){ return document.querySelector('#movie_player, .html5-video-player'); }
  function qsaDeep(base, selector, depth=4, out=[]){ if(!base) return out; try{ out.push(...base.querySelectorAll(selector)); }catch(e){} if(depth<=0) return out; const all=base.querySelectorAll('*'); for(const el of all){ const sr=el&&el.shadowRoot; if(sr) qsaDeep(sr, selector, depth-1, out); } return out; }
  const SKIP = ['.ytp-ad-skip-button-modern','button.ytp-ad-skip-button-modern','.ytp-ad-skip-button','button.ytp-ad-skip-button','.ytp-ad-skip-button-container','button.ytp-skip-ad-button','.ytp-skip-ad-button','.ytp-ad-player-overlay .ytp-button','[aria-label*=\"Skip\" i]','[class*=\"skip-button\" i]','[data-tooltip*=\"Skip\" i]'];
  function findSkip(){ const r=root(); if(!r) return null; const nodes=[]; for(const sel of SKIP) qsaDeep(r, sel, 4, nodes); for(const el of nodes){ const c = el.matches('button,.ytp-button,[role=\"button\"]') ? el : (el.querySelector && el.querySelector('button,.ytp-button,[role=\"button\"]')) || el; if(!c || c.disabled) continue; const t =(c.innerText||c.textContent||'').toLowerCase(); const a =(c.getAttribute && (c.getAttribute('aria-label')||'')).toLowerCase(); if(!(/skip/.test(t)||/skip/.test(a))) continue; if(!visible(c)) continue; return c; } return null; }
  function closeOverlay(){ const r=root(); if(!r) return null; const sels=['.ytp-ad-overlay-close-button','.ytp-ad-overlay-close-container','.ytp-ad-close-button','.ytp-ad-overlay-close-button .ytp-button','[aria-label*=\"Close\" i].ytp-button']; for(const sel of sels){ const nodes=qsaDeep(r, sel, 3, []); for(const el of nodes){ if(visible(el)) return el; } } return null; }
  function tryAct(){ const now=Date.now(); if(now-state.lastAction<THROTTLE) return false; if(now-state.lastClose>500){ const c=closeOverlay(); if(c){ burstClick(c); state.lastClose=now; } } const b=findSkip(); if(b){ burstClick(b); state.lastAction=now; setTimeout(()=>{ const bb=findSkip(); if(bb) burstClick(bb); },40); setTimeout(()=>{ const bb=findSkip(); if(bb) burstClick(bb); },120); return true;} return false; }
  function isAd(){ const p=root(); return !!p && ( p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting') || !!document.querySelector('.ytp-ad-player-overlay') || !!document.querySelector('.ytp-ad-text') || !!document.querySelector('.ytp-ad-skip-button') || !!document.querySelector('.ytp-ad-skip-button-modern') ); }
  function loop(){ const ad=isAd(); send(!!ad, ad?'youtube: ad markers present':''); if(ad) tryAct(); setTimeout(loop, ad?80:((Date.now()<state.fastUntil)?120:420)); } loop();
  (function observe(){ const r=root(); if(!r) return; const mo=new MutationObserver(()=>{ if(state.isAd) tryAct(); }); try{ mo.observe(r,{subtree:true,childList:true,attributes:true,attributeFilter:['class','style','hidden','disabled','aria-label']}); }catch(e){} })();

  chrome.runtime.onMessage.addListener((msg)=>{
    try{
      if(msg && msg.type==='FAST_WINDOW'){ if(typeof msg.ms==='number'){ state.fastUntil=Date.now()+msg.ms; } }
      if(msg && msg.type==='SYNC_NOW'){
        let isAd=false, reason='';
        isAd = (function(){ const p=document.querySelector('#movie_player, .html5-video-player'); return !!p && ( p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting') || !!document.querySelector('.ytp-ad-player-overlay') || !!document.querySelector('.ytp-ad-text') || !!document.querySelector('.ytp-ad-skip-button') || !!document.querySelector('.ytp-ad-skip-button-modern') ); })();
        reason = isAd ? 'youtube: sync markers' : '';
        chrome.runtime.sendMessage({ type:'AD_STATE', isAd: !!isAd, reason: reason || 'youtube: sync' });
      }
    }catch(e){}
  });
})();
