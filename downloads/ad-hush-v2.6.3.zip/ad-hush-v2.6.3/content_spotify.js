/* AdHush | © 2025 Escalade. All rights reserved. Proprietary — see EULA.txt. */

try { chrome.runtime.sendMessage({type:'PAGE_PING', site:'spotify'}); } catch(e) {}

(function(){
  if (window.top !== window) return;
  if (window.__admuteSpotifyLoaded) return; window.__admuteSpotifyLoaded = true;

  function norm(x){ if(x==null) return ''; if(typeof x==='string') return x; if(typeof x==='number'||typeof x==='boolean') return String(x);
    if(typeof x==='object' && typeof x.baseVal==='string') return x.baseVal; try{ return String(x); }catch(e){ return ''; } }

  function inViewport(r,vw,vh){ return r && r.bottom>0 && r.right>0 && r.left<vw && r.top<vh; }
  function isVis(el){ if(!el) return false; const st = getComputedStyle(el);
    if(st.display==='none'||st.visibility==='hidden'||+st.opacity===0) return false;
    const rs=el.getClientRects(); if(!(rs&&rs.length)) return false;
    const r=rs[0]; const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh = Math.max(document.documentElement.clientHeight, innerHeight||0);
    return inViewport(r,vw,vh);
  }
  function txt(n){ return norm(n && (n.innerText||n.textContent) || ''); }

  function walk(root, visit, cap=7000){
    const st=[root]; let n,c=0;
    while(st.length && c<cap){ n=st.pop(); if(!n) continue; c++; visit(n);
      if(n.shadowRoot) st.push(n.shadowRoot);
      const ch=n.children||n.childNodes; if(ch&&ch.length) for(let i=ch.length-1;i>=0;i--) st.push(ch[i]);
    }
  }

  const RX_ADWORD = /\b(advertisement|advertising|sponsored|sponsor|commercial)\b/i;
  const RX_ADLONE = /(^|[^a-z])ad($|[^a-z])/i;
  const RX_ADOF   = /\bad\s+\d+\s+of\s+\d+\b/i;
  const RX_LEARN  = /\blearn more\b/i;
  const RX_IGNORE = /\b(add|address|adapter|adobe|android|adjective)\b/i;

  function zones(){
    const z = [];
    const sels = [
      '[data-testid="now-playing-bar"]',
      '[class*="nowPlayingBar"]',
      'footer[role="contentinfo"]',
      '[class*="ad-"]',
      '[data-testid*="ad"]'
    ];
    for(const s of sels){ const el = document.querySelector(s); if(el) z.push(el); }
    if(!z.length){ const f = document.querySelector('footer[role="contentinfo"]'); if(f) z.push(f); }
    return z.length ? z : [document.body];
  }

  function scan(){ 
    const Z = zones();
    let found=false, reason='';
    const vw=Math.max(document.documentElement.clientWidth, innerWidth||0), vh=Math.max(document.documentElement.clientHeight, innerHeight||0);

    for(const root of Z){
      walk(root, (el)=>{
        if(found) return;
        if(el.nodeType!==1 || !isVis(el)) return;

        const inPlayer = !!(el.closest('[data-testid="now-playing-bar"], [class*="nowPlayingBar"], footer[role="contentinfo"]'));
        const r = (el.getBoundingClientRect && el.getBoundingClientRect()) || {top:vh, bottom:vh};
        const nearBottom = (r.bottom > vh - 260);
        if(!inPlayer && !nearBottom) return;

        const cl = (el.getAttribute && (el.getAttribute('class')||'')) + ' ' + (el.getAttribute && (el.getAttribute('data-testid')||''));
        if(/\b(ad-player|ad-slot|video-ad|audio-ad|display-ad)\b/i.test(cl)){ found=true; reason='spotify: class hint'; return; }

        const t = txt(el).trim(); if(!t) return;
        if(RX_IGNORE.test(t)) return;

        if(RX_ADOF.test(t)) { found=true; reason='spotify: Ad N of M'; return; }

        const container = el.closest('[data-testid], [role], [class]') || el.parentElement || el;
        const ctaText = txt(container).toLowerCase();
        const hasCTA = /\blearn more|visit|shop now|open site|details|get started\b/.test(ctaText);
        const hasAction = !!(container.querySelector && container.querySelector('a[href],button,[role="button"]'));

        if((/\badvertisement\b/i.test(t) || RX_ADWORD.test(t)) && (hasCTA || hasAction)) { found=true; reason='spotify: Advertisement'; return; }

        if(RX_ADLONE.test(t) && (/\blearn more\b/i.test(ctaText) || hasAction)) { found=true; reason='spotify: ad token + cta'; return; }
      });
      if(found) break;
    }
    return { isAd:found, reason };
  }

  const st = { isAd:false, lastChange:0, timer:0, lastTick:0, misses:0, streakAd:0, streakContent:0, coolUntil:0, fastUntil:0 };
  const FAST=140, NORMAL=360;

  function schedule(ms){ clearTimeout(st.timer); st.timer=setTimeout(tick, ms); }
  function tickSoon(){ const now=Date.now(); if(now-st.lastTick>60){ clearTimeout(st.timer); requestAnimationFrame(tick); } }

  document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) tickSoon(); });

  function send(isAd, meta){ if(st.isAd===isAd) return; st.isAd=isAd; st.lastChange=Date.now(); if(!isAd) st.coolUntil=Date.now()+900;
    chrome.runtime.sendMessage({ type:'AD_STATE', isAd, reason: meta && meta.reason });
    if(meta&&meta.reason) try{ console.debug('[Ad Mute][Spotify]', meta.reason); }catch(e){}
  }

  function tick(){
    try{
      st.lastTick=Date.now();
      let meta = scan();
      if(!meta.isAd){
        st.misses++;
        if(st.misses%12===0){ const m2 = scan(); if(m2.isAd) meta=m2; }
      } else st.misses=0;
      if(meta.isAd){ st.streakAd++; st.streakContent=0; } else { st.streakContent++; st.streakAd=0; }
      let next = st.isAd;
      if(!st.isAd){ if(st.streakAd>=2) next=true; } else { if(st.streakContent>=3) next=false; }
      if(!st.isAd && Date.now()<st.coolUntil && next) next=false;
      if(next!==st.isAd) send(next, meta);
      const since = Date.now()-st.lastChange;
      schedule((meta.isAd || since<1500) ? Math.min(80,FAST) : ((Date.now()<st.fastUntil)?120:NORMAL));
    }catch(e){ schedule(320); }
  }
  tick();

  const mo = new MutationObserver(()=>tickSoon());
  try{ mo.observe(document.documentElement, { subtree:true, childList:true, attributes:true, characterData:true }); }catch(e){}
  setInterval(tickSoon, 1500);

  chrome.runtime.onMessage.addListener((msg)=>{
    try{
      if(msg && msg.type==='FAST_WINDOW'){ if(typeof msg.ms==='number'){ st.fastUntil=Date.now()+msg.ms; } }
      if(msg && msg.type==='SYNC_NOW'){
        let isAd=false, reason='';
        const r=scan(); isAd=!!r.isAd; reason=r.reason||'';
        chrome.runtime.sendMessage({ type:'AD_STATE', isAd: !!isAd, reason: reason || 'spotify: sync' });
      }
    }catch(e){}
  });
})();
