/* AdHush | © 2025 Escalade. All rights reserved. Proprietary — see EULA.txt. */

(function(){
  'use strict';
  if (window.top !== window) return;
  if (window.__adhushOverlayLoaded) return;
  window.__adhushOverlayLoaded = true;

  const isNetflix = /(^|\.)netflix\.com$/.test(location.hostname);

  const host = document.createElement('div');
  host.id = 'adhush-overlay-host';
  host.style.position = 'fixed';
  host.style.zIndex = '2147483647';
  host.style.pointerEvents = 'none';
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode:'open' });
  const style = document.createElement('style');
  style.textContent = `
/* Nano mode: extremely compact. Single row of 3 pills only. */
:host([nano="1"]){ --gap:6px; }
:host([nano="1"]) .sheet{ padding:4px 6px; border-radius:12px; }
:host([nano="1"]) .brand{ display:none !important; }
:host([nano="1"]) .signal{ display:none !important; }
:host([nano="1"]) .pill.strict{ display:none !important; }
:host([nano="1"]) .pill{ padding:4px 8px; border-radius:10px; font-size:12px; line-height:1.05; min-width:0; }
:host([nano="1"]) .pill.auto{ padding-left:10px; padding-right:10px; }

/* Ultra-compact micro mode for the tiniest widths */
:host([micro="1"]){ --gap:6px; }
:host([micro="1"]) .sheet{ padding:4px 6px; border-radius:12px; }
:host([micro="1"]) .brand{ display:none; }
:host([micro="1"]) .pill{ padding:5px 9px; border-radius:10px; font-size:13px; line-height:1.1; min-width:0; }
:host([micro="1"]) .pill.auto{ padding-left:10px; padding-right:10px; }
:host([micro="1"]) .signal{ font-size:11.5px; opacity:.95; border-left:0 !important; padding-left:0 !important; }

/* Ultra-compact narrow mode */
:host([narrow="1"]){ --gap:8px; }
:host([narrow="1"]) .sheet{ padding:6px 8px; border-radius:14px; }
:host([narrow="1"]) .brand{ display:none; }
:host([narrow="1"]) .pill{ padding:6px 10px; border-radius:12px; font-size:14px; line-height:1.15; min-width:0; }
:host([narrow="1"]) .pill.auto{ padding-left:12px; padding-right:12px; }
:host([narrow="1"]) .signal{ font-size:12px; opacity:.95; }

/* --- Two modes: wide (default) and narrow --- */
#adhush-bar{ display:flex; align-items:center; flex-wrap:nowrap; gap: var(--gap,14px); }
.signal{ white-space:nowrap; overflow:hidden; text-overflow:ellipsis; flex:1 1 auto; min-width:0; }
:host([narrow="1"]) .sheet{ padding:8px 10px; border-radius:16px; }
:host([narrow="1"]) .brand span:nth-child(2){ display:none; } /* hide 'AdHush' text */
:host([narrow="1"]) .pill{ padding:8px 12px; border-radius:12px; }
:host([narrow="1"]) .pill .label{ font-size:14px; } /* if labels wrapped inside */
:host([narrow="1"]) .signal{ font-size:13px; opacity:.95; }

/* --- Single-row, flexible status, condensed mode --- */
#adhush-bar{ display:flex; align-items:center; flex-wrap: nowrap; gap: var(--gap, 14px); }
.signal{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1 1 auto; min-width: 0; }
:host([narrow="1"]) .sheet{ padding:8px 10px; border-radius:16px; }
:host([narrow="1"]) .brand span:nth-child(2){ display:none; } /* hide 'AdHush' text */
:host([narrow="1"]) .pill{ padding:8px 12px; border-radius:12px; }

    :host{ all: initial; }
    *{ box-sizing:border-box; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; }
    .wrap{ display:inline-flex; pointer-events:auto; }
    .sheet{ position:relative; color:#eaf1ff; background:linear-gradient(180deg, rgba(15,19,30,.78), rgba(8,11,20,.74));
      border:1px solid rgba(170,192,255,.20); border-radius:18px; padding:10px 12px; box-shadow:0 18px 50px rgba(0,0,0,.45), inset 0 0 0 1px rgba(255,255,255,.04);
      backdrop-filter:saturate(1.2) blur(8px); -webkit-backdrop-filter:saturate(1.2) blur(8px);
      display:inline-flex; align-items:center; gap:12px; max-width:96vw; max-height:96vh; }
    .brand{ display:flex; align-items:center; gap:8px; padding:6px 10px; border-radius:12px; background:linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.02));
      box-shadow:inset 0 1px 0 rgba(255,255,255,.06); font-weight:700; letter-spacing:.2px; color:#dbe5ff; font-size:12px; }
    .badge{ width:18px; height:18px; border-radius:6px; background:linear-gradient(180deg,#7aa2ff,#5b8bff); color:#071022; display:inline-flex; align-items:center; justify-content:center;
      font-weight:900; font-size:11px; box-shadow:0 2px 8px rgba(91,139,255,.45), inset 0 0 0 1px rgba(255,255,255,.35); }
    .bar{ display:flex; align-items:center; gap:10px; }
    :host([vertical="1"]) .bar{ flex-direction:column; gap:8px; } :host([vertical="1"]) .signal{ display:none; }
    .pill{ border:1px solid rgba(255,255,255,.08); border-radius:14px; padding:10px 16px; font-weight:800; letter-spacing:.2px; cursor:pointer;
      background:linear-gradient(180deg, #121826, #0b1220); color:#eaf1ff; box-shadow:inset 0 0 0 1px rgba(255,255,255,.02); transition:transform .12s ease, box-shadow .12s ease, background .12s ease; user-select:none; }
    .pill:hover{ transform:translateY(-1px); box-shadow:0 6px 16px rgba(0,0,0,.28), inset 0 0 0 1px rgba(255,255,255,.04); }
    .pill.mute{ background:linear-gradient(180deg,#ef4444,#dc2626); color:#fff; } .pill.unmute{ background:linear-gradient(180deg,#22c55e,#16a34a); color:#041c10; }
    .pill.auto{ background:linear-gradient(180deg,#1f2937,#0f172a); color:#e5e7eb; } .pill.active{ outline:2px solid #9db8ff; }
    .pill.mode{ background:linear-gradient(180deg,#0e1627,#0a1220); color:#cbd5e1; padding:8px 14px; font-weight:700; }
    .signal{ font-size:12px; color:#a9b4cf; padding:6px 8px; white-space:nowrap; border-left:1px solid rgba(255,255,255,.06); margin-left:2px; }
    .close{ background:transparent; border:none; color:#9fb3cb; font-size:16px; line-height:1; padding:6px 8px; cursor:pointer; border-radius:10px; }
    .puck{ display:none!important; pointer-events:auto; width:38px; height:38px; border-radius:12px; border:1px solid rgba(159,183,255,.28);
      background:linear-gradient(180deg, rgba(14,18,30,.9), rgba(9,12,20,.88)); box-shadow:0 10px 24px rgba(0,0,0,.40); align-items:center; justify-content:center; color:#eaf1ff; font-weight:800; }
    .puck::after{ content:"AH"; font-size:12px; letter-spacing:.5px; }
  `;
  shadow.appendChild(style);

  const wrap = document.createElement('div'); wrap.className='wrap'; wrap.style.display='none';
  const sheet = document.createElement('div'); sheet.className='sheet';
  sheet.innerHTML = `
    <div class="bar" id="adhush-bar">
      <div class="brand"><span class="badge">AH</span><span>AdHush</span></div>
      <button class="pill mute">Mute</button>
      <button class="pill unmute">Unmute</button>
      <button class="pill auto">Auto</button>
      <span class="signal" id="ovl-signal">—</span>
      ${isNetflix ? '<button class="pill mode" id="nx-mode-btn">Strict</button>' : ''}
      <button class="close" title="Close overlay">✕</button>
    </div>`;
  wrap.appendChild(sheet); shadow.appendChild(wrap);
  const puck = document.createElement('div'); puck.className='puck'; shadow.appendChild(puck);
  const $ = (sel)=>shadow.querySelector(sel);

  // Docking
  function applyDock(dock){
    const v = (dock==='top'||dock==='bottom'||dock==='left'||dock==='right') ? dock : 'bottom';
    host.removeAttribute('vertical'); host.style.left=host.style.right=host.style.top=host.style.bottom=''; host.style.transform='';
    if (v==='top'){ host.style.left='50%'; host.style.top='18px'; host.style.transform='translateX(-50%)'; }
    if (v==='bottom'){ host.style.left='50%'; host.style.bottom='18px'; host.style.transform='translateX(-50%)'; }
    if (v==='left'){ host.style.left='18px'; host.style.top='50%'; host.style.transform='translateY(-50%)'; host.setAttribute('vertical','1'); }
    if (v==='right'){ host.style.right='18px'; host.style.top='50%'; host.style.transform='translateY(-50%)'; host.setAttribute('vertical','1'); }
    try{ chrome.storage.local.set({ adhush_dock:v, admute_dock:v }); }catch{}
  }
  applyDock('bottom');
  try{ chrome.storage.local.get({ adhush_dock:'bottom', admute_dock:null }, r => applyDock(r.adhush_dock||r.admute_dock||'bottom')); }catch{}

  function setVisible(v){ wrap.style.display = v ? 'inline-flex' : 'none'; puck.style.display = 'none'; }
  function setActiveMode(force){ const m=$('.pill.mute'), u=$('.pill.unmute'), a=$('.pill.auto'); [m,u,a].forEach(b=>b.classList.remove('active'));
    if(force===true){ m.classList.add('active'); a.textContent='Manual'; } else if(force===false){ u.classList.add('active'); a.textContent='Manual'; }
    else { a.classList.add('active'); a.textContent='Auto'; } }
  function setFromPayload(res){
    if(!res) return;
    const sig=$('#ovl-signal'); if(sig){ sig.textContent = 'Now: ' + (res.isAd ? 'AD' : 'content') + '  •  ' + 'Muted: ' + (res.muted?'yes':'no') + (res.reason?(' — '+res.reason):''); }
    setActiveMode(res.force);
  }
  function refresh(){ try{ chrome.runtime.sendMessage({type:'GET_STATE'}, res=>{ if(res?.ok) setFromPayload(res); }); }catch{} }

  $('.pill.mute').addEventListener('click', ()=>{ try{ chrome.runtime.sendMessage({type:'FORCE_STATE', force:true},  refresh); }catch{} });
  $('.pill.unmute').addEventListener('click', ()=>{ try{ chrome.runtime.sendMessage({type:'FORCE_STATE', force:false}, refresh); }catch{} });
  $('.pill.auto').addEventListener('click',  ()=>{ try{ chrome.runtime.sendMessage({type:'FORCE_STATE', force:null}, refresh); chrome.runtime.sendMessage({type:'FAST_WINDOW', ms:2200}); chrome.runtime.sendMessage({type:'SYNC_NOW'});}catch{} });
  $('.close').addEventListener('click', ()=> setVisible(false));
  // puck click disabled

  if(isNetflix){
    try{ chrome.storage.local.get({ adhush_nx_mode:'strict', admute_nx_mode:'strict' }, r=>{ const btn=$('#nx-mode-btn'); if(!btn) return;
      const cur=r.adhush_nx_mode||r.admute_nx_mode||'strict'; btn.textContent=(cur==='balanced')?'Balanced':'Strict';
      btn.addEventListener('click', ()=>{ chrome.storage.local.get({ adhush_nx_mode:cur }, r2=>{ const next=((r2.adhush_nx_mode||cur)==='balanced')?'strict':'balanced';
        chrome.storage.local.set({ adhush_nx_mode:next, admute_nx_mode:next }, ()=>{ btn.textContent=(next==='balanced')?'Balanced':'Strict'; chrome.runtime.sendMessage({ type:'NX_MODE', mode:next }); }); }); }); }); }catch{}
  }

  try{ chrome.runtime.onMessage.addListener(msg=>{ if(msg?.type==='STATE_PUSH') setFromPayload(msg); else if(msg?.type==='OVERLAY_TOGGLE'){ setVisible(wrap.style.display==='none'); if(wrap.style.display!=='none') refresh(); } }); }catch{}

  // Drag + snap
  let dragging=false,startX=0,startY=0,startRect=null,pointerId=null;
  const HANDLE=shadow.getElementById('adhush-bar');
  function nearestDock(){ const r=host.getBoundingClientRect(); const vw=Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh=Math.max(document.documentElement.clientHeight, innerHeight||0); const cx=r.left+r.width/2, cy=r.top+r.height/2;
    const dist={ top:cy, bottom:vh-cy, left:cx, right:vw-cx }; let dock='bottom',best=Infinity; for(const k of ['top','bottom','left','right']){ const v=dist[k]; if(v<best){best=v; dock=k;} } return dock; }
  function onDown(e){ if(e.button!==0) return; if(e.target.closest('button')) return; dragging=true; e.preventDefault();
    pointerId=e.pointerId; try{ HANDLE.setPointerCapture(pointerId);}catch{} const r=host.getBoundingClientRect(); startX=e.clientX; startY=e.clientY; startRect=r;
    host.style.transition='none'; host.style.left=r.left+'px'; host.style.top=r.top+'px'; host.style.right=''; host.style.bottom=''; host.style.transform='translate(0,0)'; }
  function onMove(e){ if(!dragging) return; const dx=e.clientX-startX, dy=e.clientY-startY; const vw=Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh=Math.max(document.documentElement.clientHeight, innerHeight||0); const w=startRect.width,h=startRect.height; let nx=startRect.left+dx, ny=startRect.top+dy;
    nx=Math.min(Math.max(nx, -w+4), vw-4); ny=Math.min(Math.max(ny, -h+4), vh-4); host.style.left=nx+'px'; host.style.top=ny+'px'; }
  function onUp(){ if(!dragging) return; dragging=false; try{ HANDLE.releasePointerCapture(pointerId);}catch{} pointerId=null; host.style.transition=''; applyDock(nearestDock()); }
  HANDLE.addEventListener('pointerdown', onDown); document.addEventListener('pointermove', onMove, {passive:true});
  document.addEventListener('pointerup', onUp); document.addEventListener('pointercancel', onUp);

  setTimeout(()=>{ setVisible(false); refresh(); }, 400);
  __adhush_layout();
  function __adhush_layout(){
  try{
    const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
    // Prefer a threshold; also measure overflow as a fallback
    const threshold = 1000; const microThreshold = 820; const nanoThreshold = 700;
    const overflow = sheet.scrollWidth > (vw - 24);
    const narrow = vw < threshold || overflow;
    const micro = vw < microThreshold || (narrow && sheet.scrollWidth > vw - 24);
      const nano = vw < nanoThreshold || (micro && sheet.scrollWidth > vw - 24);
      if (nano){ host.setAttribute('nano','1'); host.setAttribute('micro','1'); host.setAttribute('narrow','1'); }
      else if (micro){ host.removeAttribute('nano'); host.setAttribute('micro','1'); host.setAttribute('narrow','1'); }
      else { host.removeAttribute('nano'); host.removeAttribute('micro'); if (narrow) host.setAttribute('narrow','1'); else host.removeAttribute('narrow'); }
  }catch(e){}
}
try{ new ResizeObserver(()=>__adhush_layout()).observe(sheet); }catch(e){}
window.addEventListener('resize', __adhush_layout, { passive:true });
  __adhush_updateCondensed();
  function __adhush_updateCondensed(){
  try{
    const vw = Math.max(document.documentElement.clientWidth, innerWidth||0);
    // Keep a small buffer so the pill doesn't kiss the edge
    const need = sheet.scrollWidth > (vw - 32);
    if (need) host.setAttribute('condensed','1'); else host.removeAttribute('condensed');
  }catch(e){ /* no-op */ }
}
try{ new ResizeObserver(()=>__adhush_updateCondensed()).observe(sheet); }catch(e){}
window.addEventListener('resize', __adhush_updateCondensed, { passive:true });
})();
