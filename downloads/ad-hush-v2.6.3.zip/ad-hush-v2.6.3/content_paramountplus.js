/* AdHush | © 2025 Kaboombooo. All rights reserved. Proprietary — see EULA.txt. */
try { chrome.runtime.sendMessage({ type:'PAGE_PING', site:'paramountplus' }); } catch(e) {}

(function () {
  'use strict';
  if (window.top !== window) return;
  if (window.__adhushParamount_hotfix) return; window.__adhushParamount_hotfix = true;

  // ---- Tunables ----
  const FAST_MS = 80;
  const SLOW_MS = 900;

  const DEBOUNCE_MS = 40;
  const LATCH_MS = 900;

  const EXIT_CLEAN_SCANS = 3;
  const EXIT_FAST_MS = 900;

  const TL_TOP = 0.28;     // top-left region focus
  const TL_LEFT = 0.45;

  // ---- Utils ----
  const now = () => Date.now();

  const T = (el) => el ? ((el.innerText || el.textContent || '').trim()) : '';

  const V = (el) => {
    if (!el || !el.isConnected) return false;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || +cs.opacity === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 6 && r.height > 6 && r.bottom > 0 && r.right > 0 &&
           r.left < (innerWidth || 1) && r.top < (innerHeight || 1);
  };

  const inTL = (el) => {
    const r = el.getBoundingClientRect();
    const vw = Math.max(document.documentElement.clientWidth, innerWidth || 0);
    const vh = Math.max(document.documentElement.clientHeight, innerHeight || 0);
    return r.top >= 0 && r.top < vh * TL_TOP && r.left >= 0 && r.left < vw * TL_LEFT;
  };

  function bigVideo() {
    let best = null, area = 0;
    for (const v of document.querySelectorAll('video')) {
      const r = v.getBoundingClientRect();
      const a = r.width * r.height;
      if (a > area) { best = v; area = a; }
    }
    return best;
  }

  function playerRoot() {
    // Paramount+ is fairly SPA-ish; safest root is body if we can’t scope tightly.
    const v = bigVideo();
    if (!v) return document.body;
    return v.closest('main, [role="main"], body') || document.body;
  }

  // ---- Paramount+ Ad Detection ----
  // Based on your screenshots: TL badge contains:
  //  - A circular countdown number (e.g., 27, 119)
  //  - The word "Advertisement"
  //
  // We detect either:
  //  - a visible TL element with exact text "Advertisement" (case-insensitive), OR
  //  - a visible TL element that looks like a small countdown badge (1–3 digits) *near* an Advertisement label
  function findTLTextNodes(root) {
    // Keep this light: only scan common HUD elements
    return root.querySelectorAll('div, span, button, a, p');
  }

  function hasAdvertisementLabel(root) {
    const nodes = findTLTextNodes(root);
    for (const el of nodes) {
      if (!V(el) || !inTL(el)) continue;
      const s = T(el);
      if (!s) continue;
      if (s.trim().toLowerCase() === 'advertisement') return true;
    }
    return false;
  }

  function findCountdownCandidate(root) {
    const nodes = findTLTextNodes(root);
    for (const el of nodes) {
      if (!V(el) || !inTL(el)) continue;
      const s = T(el);
      if (!s) continue;
      const t = s.trim();
      if (!/^\d{1,3}$/.test(t)) continue;

      // Heuristic: countdown badge is usually small-ish
      const r = el.getBoundingClientRect();
      if (r.width <= 90 && r.height <= 90) return el;
    }
    return null;
  }

  function isAdPlaying() {
    const root = playerRoot();
    if (!root) return false;

    // Strong signal: label is present
    if (hasAdvertisementLabel(root)) return true;

    // Secondary: countdown badge present AND label present somewhere (even if label isn’t TL-visible due to transitions)
    const cd = findCountdownCandidate(root);
    if (cd) {
      // Check the broader root text lightly (avoid full body.innerText cost)
      const nearby = cd.parentElement ? (T(cd.parentElement) + ' ' + T(root)).toLowerCase() : T(root).toLowerCase();
      if (nearby.includes('advertisement')) return true;
    }

    return false;
  }

  // ---- State machine + publish (match Prime contract) ----
  let state = { isAd: false, reason: 'content' };
  let latchUntil = 0;
  let cleanScans = 0;

  function publish(isAd, reason) {
    if (state.isAd === isAd) return;
    state = { isAd, reason };

    try { chrome.runtime.sendMessage({ type:'AD_STATE', isAd: state.isAd, reason: state.reason }); } catch(e) {}
    try {
      document.dispatchEvent(new CustomEvent('adhush:state', {
        detail: { site:'paramountplus', isAd: state.isAd, reason: state.reason, ts: now() }
      }));
    } catch(e) {}
    try {
      window.postMessage({ source:'adhush', site:'paramountplus', type:'state', isAd: state.isAd, reason: state.reason, ts: now() }, '*');
    } catch(e) {}
  }

  function step() {
    const evidence = isAdPlaying();
    const t = now();

    let next = state.isAd;

    if (!state.isAd) {
      if (evidence) {
        next = true;
        cleanScans = 0;
        latchUntil = t + LATCH_MS;
      }
    } else {
      if (evidence) {
        next = true;
        cleanScans = 0;
        latchUntil = t + LATCH_MS; // keep latching while evidence persists
      } else if (t < latchUntil) {
        next = true; // hold briefly to prevent flicker
      } else {
        cleanScans++;
        if (cleanScans >= EXIT_CLEAN_SCANS) {
          next = false;
          cleanScans = 0;
        }
      }
    }

    return next;
  }

  // ---- Adaptive cadence + observers (Prime-like) ----
  let fastUntil = 0;
  let timer = null;
  let pending = false;
  let rafPending = false;

  function inFast() { return now() < fastUntil; }
  function bumpFast(ms = 4500) { fastUntil = Math.max(fastUntil, now() + ms); }
  function cadence() { return inFast() ? FAST_MS : SLOW_MS; }

  function schedule(ms) { clearTimeout(timer); timer = setTimeout(scan, ms); }

  function scanNow() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => {
      rafPending = false;
      pending = false;
      const next = step();
      publish(next, next ? 'ad' : 'content');
      schedule(cadence());
    });
  }

  function scan() {
    pending = false;
    const next = step();
    publish(next, next ? 'ad' : 'content');
    schedule(cadence());
  }

  function debounced() {
    if (pending) return;
    pending = true;
    setTimeout(() => { bumpFast(); scanNow(); }, DEBOUNCE_MS);
  }

  let mo;
  function watch() {
    const r = playerRoot();
    try { if (mo) mo.disconnect(); } catch(e) {}
    if (!r) return;

    mo = new MutationObserver(debounced);
    try {
      mo.observe(r, {
        subtree: true,
        childList: true,
        attributes: true,
        characterData: true,
        attributeFilter: ['class', 'style', 'hidden', 'aria-label', 'role']
      });
    } catch(e) {}
  }

  // history pushState hook (Prime-style)
  (function hookHistory() {
    const o = history.pushState;
    history.pushState = function () {
      const r = o.apply(this, arguments);
      try { dispatchEvent(new Event('pushstate')); } catch(e) {}
      return r;
    };
  })();

  // Event bumps
  ['popstate', 'pushstate', 'hashchange', 'pageshow', 'visibilitychange', 'focus'].forEach(e => {
    addEventListener(e, () => {
      watch();
      bumpFast(4500);
      debounced();
    }, { passive: true });
  });

  // Initial
  watch();
  bumpFast(3500);
  scan();

  // Public handle
  window.__ADHUSH_PARAMOUNTPLUS__ = { state: () => state, forceScan: scanNow };
})();
