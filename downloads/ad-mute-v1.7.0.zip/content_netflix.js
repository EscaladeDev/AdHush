/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */

(function(){
  if (window.top !== window) return;
  if (window.__admuteNetflixLoaded) return; window.__admuteNetflixLoaded = true;
  let MODE = 'strict'; chrome.storage.local.get({ admute_nx_mode:'strict' }, (r)=>{ MODE=r.admute_nx_mode; });
  chrome.runtime.onMessage.addListener((msg)=>{ if(msg?.type==='NX_MODE' && (msg.mode==='strict'||msg.mode==='balanced')) MODE=msg.mode; });

  function norm(x){ if(x==null) return ''; if(typeof x==='string') return x; if(typeof x==='number'||typeof x==='boolean') return String(x); if(typeof x==='object'&&typeof x.baseVal==='string') return x.baseVal; try{return String(x);}catch(e){return '';} }
  function inViewport(r,vw,vh){ return r && r.bottom>0 && r.right>0 && r.left<vw && r.top<vh; }
  function isVis(el){ if(!el) return false; const st=getComputedStyle(el); if(st.display==='none'||st.visibility==='hidden'||+st.opacity===0) return false; const rects=el.getClientRects(); if(!(rects&&rects.length)) return false; const r=rects[0]; const vw=Math.max(document.documentElement.clientWidth, innerWidth||0), vh=Math.max(document.documentElement.clientHeight, innerHeight||0); return inViewport(r,vw,vh); }
  function walk(root, fn, cap=6000){ const st=[root]; let n,c=0; while(st.length && c<cap){ n=st.pop(); if(!n) continue; c++; fn(n); if(n.shadowRoot) st.push(n.shadowRoot); const ch=n.children||n.childNodes; if(ch&&ch.length){ for(let i=ch.length-1;i>=0;i--) st.push(ch[i]); } } }
  function txt(n){ return norm(n && (n.innerText||n.textContent) || ''); }

  const RX_AD=/(^|[\s•:–—-])ad($|[\s•:–—-])/i, RX_WORD=/^ad$/i, RX_MMSS=/\b\d{1,2}:\d{2}\b/, RX_ADOF=/\bad\s+\d+\s+of\s+\d+\b/i, RX_LEARN=/\blearn more\b/i, RX_IGNORE=/^(audio|subtitles|cc|next episode|skip intro|back|\d+x)$/i;

  function scan(root){
    const vw=Math.max(document.documentElement.clientWidth, innerWidth||0), vh=Math.max(document.documentElement.clientHeight, innerHeight||0);
    let found=false, reason='';
    walk(root, (el)=>{
      if(found) return; if(el.nodeType!==1 || !isVis(el)) return;
      const t=txt(el).trim(); if(!t || RX_IGNORE.test(t)) return;
      if(RX_ADOF.test(t)){ const b=el.getBoundingClientRect(); const left=b.x<vw*0.50, right=b.x>vw*0.50, top=b.y<vh*0.30, bottom=b.y>vh*0.58; if(MODE==='strict'){ if((left&&top)||(left&&bottom)||(right&&top)){ found=true; reason='netflix(strict): Ad N of M (corner)'; } } else { found=true; reason='netflix(bal): Ad N of M'; } return; }
      if(RX_WORD.test(t)||RX_AD.test(t)){ const p=el.parentElement||el; const pt=txt(p); const b=(p.getBoundingClientRect&&p.getBoundingClientRect())||{x:0,y:0}; const left=b.x<vw*0.50, right=b.x>vw*0.50, top=b.y<vh*0.30, bottom=b.y>vh*0.58; const hasBuddy=RX_MMSS.test(pt)||RX_LEARN.test(pt)||RX_ADOF.test(pt)||(()=>{const pa=p.parentElement; if(!pa) return false; for(const ch of Array.from(pa.childNodes)){ if(ch===el) continue; const s=(ch.nodeType===3?String(ch.nodeValue||''):(ch.nodeType===1?(ch.innerText||ch.textContent||''):'')).trim(); if(/^\d{1,3}$/.test(s)){ const n=parseInt(s,10); if(n>0&&n<=600) return true; } } return false; })(); if(MODE==='strict'){ if(hasBuddy && ((left&&top)||(left&&bottom)||(right&&top))){ found=true; reason='netflix(strict): Ad + buddy (corner)'; } } else { if(hasBuddy){ found=true; reason='netflix(bal): Ad + buddy'; } } }
    });
    return { isAd:found, reason };
  }

  const st={ isAd:false, lastChange:0, timer:0, lastTick:0, misses:0, streakAd:0, streakContent:0, coolUntil:0 };
  const FAST=100, NORMAL=240;
  function schedule(ms){ clearTimeout(st.timer); st.timer=setTimeout(tick, ms); }
  function tickSoon(){ const now=Date.now(); if(now-st.lastTick>50){ clearTimeout(st.timer); requestAnimationFrame(tick); } }
  document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) tickSoon(); });

  function getRoot(){ const v=document.querySelector('video'); if(!v) return document.body; const r=v.closest('[role=\"application\"],[data-uia*=\"player\"],[class*=\"player\"]'); return r||v.parentElement||document.body; }
  function send(isAd, meta){ if(st.isAd===isAd) return; st.isAd=isAd; st.lastChange=Date.now(); if(!isAd){ st.coolUntil=Date.now()+1200; } chrome.runtime.sendMessage({ type:'AD_STATE', isAd, reason: meta && meta.reason }); if(meta&&meta.reason) console.debug('[Ad Mute][Netflix] reason:', meta.reason); }
  function tick(){ try{ st.lastTick=Date.now(); const root=getRoot(); let meta=scan(root); if(!meta.isAd){ st.misses++; if(st.misses%18===0){ const m2=scan(document.body); if(m2.isAd) meta=m2; } } else st.misses=0; // hysteresis
      if(meta.isAd){ st.streakAd++; st.streakContent=0; } else { st.streakContent++; st.streakAd=0; }
      let next=st.isAd; if(!st.isAd){ if(st.streakAd>=2) next=true; } else { if(st.streakContent>=3) next=false; }
      if(!st.isAd && Date.now()<st.coolUntil && next) next=false;
      if(next!==st.isAd) send(next, meta);
      const since=Date.now()-st.lastChange; schedule((meta.isAd||since<1800)?FAST:NORMAL);
    }catch(e){ schedule(300); } }
  tick();
  let mo=new MutationObserver(()=>tickSoon());
  function watch(){ const r=getRoot(); try{ mo.disconnect(); mo.observe(r,{subtree:true,childList:true,characterData:true}); }catch(e){} }
  watch();
  (function hook(){ const v=document.querySelector('video'); if(!v){ setTimeout(hook,800); return; } v.addEventListener('timeupdate',tickSoon,{passive:true}); v.addEventListener('seeking',tickSoon,{passive:true}); v.addEventListener('ratechange',tickSoon,{passive:true}); setInterval(watch,2000); })();
})();
