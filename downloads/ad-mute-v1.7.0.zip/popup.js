/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */

let POLLER=0, ACTIVE_TAB_ID=null;
function setUI(data){
  const stateEl=document.getElementById('state'); const p=document.getElementById('p');
  if(data?.unsupported){ stateEl.textContent='Open YouTube/Netflix/Disney+ to use'; document.querySelector('.ring').style.setProperty('--pct','0%'); p.textContent='—'; return; }
  if(!data||!data.ok){ stateEl.textContent='No data'; document.querySelector('.ring').style.setProperty('--pct','0%'); p.textContent='0.00'; return; }
  stateEl.textContent = data.effective ? 'Ad detected — muted' : (data.muted ? 'Muted' : 'No ad');
  const pct = data.effective ? 100 : 0;
  document.querySelector('.ring').style.setProperty('--pct', pct + '%');
  p.textContent = data.effective ? '1.00' : '0.00';
  document.getElementById('k-nov').style.left = (pct) + '%';
  document.getElementById('k-int').style.left = (pct) + '%';
  document.getElementById('k-net').style.left = (pct) + '%';
  document.getElementById('v-nov').textContent = data.effective ? '1.00' : '0.00';
  document.getElementById('v-int').textContent = data.effective ? '1.00' : '0.00';
  document.getElementById('v-net').textContent = data.effective ? '1.00' : '0.00';
}
function isSupportedUrl(url){ try{ const u=new URL(url); return /(^|\.)youtube\.com$/.test(u.hostname) || /(^|\.)netflix\.com$/.test(u.hostname) || /(^|\.)disneyplus\.com$/.test(u.hostname); }catch(e){ return false; } }
async function refresh(){ const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); if(!tab||!isSupportedUrl(tab.url||'')){ setUI({unsupported:true}); return; } ACTIVE_TAB_ID=tab.id; chrome.tabs.sendMessage(tab.id,{ping:true},()=>{ void chrome.runtime.lastError; }); chrome.runtime.sendMessage({type:'GET_STATE', tabId:tab.id}, (res)=>{ if(chrome.runtime.lastError){ setUI({ok:false}); return; } setUI(res); }); }
chrome.runtime.onMessage.addListener((msg)=>{ if(msg?.type==='STATE_PUSH'){ if(ACTIVE_TAB_ID && msg.tabId===ACTIVE_TAB_ID) setUI(msg); } });
function startPolling(){ clearInterval(POLLER); POLLER=setInterval(()=>{ chrome.runtime.sendMessage({type:'GET_STATE', tabId:ACTIVE_TAB_ID}, (res)=>{ if(!chrome.runtime.lastError && res?.ok) setUI(res); }); }, 400); } function stopPolling(){ clearInterval(POLLER); POLLER=0; }
document.getElementById('inject').addEventListener('click', refresh);
document.addEventListener('DOMContentLoaded', ()=>{ refresh(); startPolling(); });
window.addEventListener('unload', stopPolling);
document.getElementById('toggleOverlay').addEventListener('click',(e)=>{ e.preventDefault(); chrome.runtime.sendMessage({type:'OVERLAY_TOGGLE'}); });
