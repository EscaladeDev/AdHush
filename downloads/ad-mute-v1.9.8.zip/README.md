# Ad Mute — Continuity Guard (v1.9.0)

- Draggable overlay with **edge snap** (top/bottom/left/right) and **slim vertical** layout for side edges.
- Netflix: detects **“Ad 15”** countdowns (corner-aware in Strict; anywhere in Balanced).
- Spotify: detection limited to player/footer; requires CTA/button near “Advertisement” to avoid false mutes.
- Overlay “Now:” reflects detector (`isAd`), not manual override.
- Quick re-sync when switching back to Auto.

Install (dev): `chrome://extensions` → Developer mode → Load unpacked → select this folder.
