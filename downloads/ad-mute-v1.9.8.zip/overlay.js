/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */
(function(){
  if (window.top !== window) return;
  if (window.__admuteOverlayLoaded) return;
  window.__admuteOverlayLoaded = true;

  const isNetflix = /(^|\.)netflix\.com$/.test(location.hostname);

  // Host element positioned by inline styles (snap anchors)
  const host = document.createElement('div');
  host.id = 'admute-overlay-host';
  host.style.position = 'fixed';
  host.style.zIndex = '2147483647';
  host.style.pointerEvents = 'none'; // turn on for inner bar only
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({mode:'open'});

  // Shadow-scoped styles to avoid page CSS conflicts
  const style = document.createElement('style');
  style.textContent = `
    :host{ all: initial; }
    * { box-sizing: border-box; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; }
    .wrap{ display:inline-flex; pointer-events:auto; }
    .sheet{
      --ink:#eaf1ff; --muted:#a9b4cf; --ring:#93c5fd; --glow:rgba(127,156,245,.35);
      color:var(--ink);
      background:linear-gradient(180deg, rgba(13,17,26,.92), rgba(10,13,21,.88));
      border:1px solid rgba(159,183,255,.18);
      border-radius:999px;
      padding:8px 10px;
      box-shadow:0 16px 44px rgba(0,0,0,.45), inset 0 0 0 1px rgba(255,255,255,.04);
      backdrop-filter:saturate(1.15) blur(6px);
      -webkit-backdrop-filter:saturate(1.15) blur(6px);
      display:inline-flex; align-items:center; gap:10px;
      max-width:96vw; max-height:96vh;
    }
    .bar{ display:flex; align-items:center; gap:10px; }
    :host([vertical="1"]) .bar{ flex-direction:column; gap:8px; }
    :host([vertical="1"]) .signal{ display:none; }
    .pill{
      border:1px solid rgba(255,255,255,.06); border-radius:999px;
      padding:10px 16px; font-weight:800; letter-spacing:.2px; cursor:pointer;
      background:linear-gradient(180deg, #111827, #0b1220); color:#eaf1ff;
      box-shadow:inset 0 0 0 1px rgba(255,255,255,.02);
      transition:transform .12s ease, box-shadow .12s ease, background .12s ease;
      user-select:none;
    }
    .pill:hover{ transform:translateY(-1px); box-shadow:0 4px 16px rgba(0,0,0,.25), inset 0 0 0 1px rgba(255,255,255,.04); }
    .pill:active{ transform:translateY(0); }
    .pill.mute{ background:linear-gradient(180deg,#ef4444,#dc2626); color:#fff; border-color:rgba(255,255,255,.12); }
    .pill.unmute{ background:linear-gradient(180deg,#22c55e,#16a34a); color:#041c10; border-color:rgba(255,255,255,.08); }
    .pill.auto{ background:linear-gradient(180deg,#1f2937,#111827); color:#e5e7eb; }
    .pill.active{ outline:2px solid var(--ring); box-shadow:inset 0 0 0 2px rgba(147,197,253,.25), 0 0 0 3px var(--glow); }
    .pill.mode{ background:linear-gradient(180deg,#0e1627,#0a1220); color:#cbd5e1; padding:8px 14px; font-weight:700; }
    .signal{ font-size:12px; color:var(--muted); padding:4px 8px; white-space:nowrap; }
    .close{ background:transparent; border:none; color:#94a3b8; font-size:16px; line-height:1; padding:6px 8px; cursor:pointer; }
    .close:hover{ color:#c7d2fe; }
    @media (max-width:560px){
      .sheet{ padding:6px; }
      .pill{ padding:10px 12px; }
      .signal{ display:none; }
    }
  `;
  shadow.appendChild(style);

  const wrap = document.createElement('div');
  wrap.className = 'wrap';
  wrap.style.display = 'none'; // shown on init
  const sheet = document.createElement('div');
  sheet.className = 'sheet';
  sheet.innerHTML = `
      <div class="bar" id="admute-bar">
        <button class="pill mute"   title="Force mute (treat as Ad)">Mute</button>
        <button class="pill unmute" title="Force unmute (treat as Content)">Unmute</button>
        <button class="pill auto"   title="Return to automatic detection">Auto</button>
        <span class="signal" id="ovl-signal">—</span>
        ${isNetflix ? '<button class="pill mode" id="nx-mode-btn" title="Toggle Strict/Balanced for Netflix">Strict</button>' : ''}
        <button class="close" title="Close">✕</button>
      </div>
  `;
  wrap.appendChild(sheet);
  shadow.appendChild(wrap);

  const $ = (sel)=>shadow.querySelector(sel);

  // docking via inline style on host
  const DOCK_KEY = "admute_dock";
  function applyDock(dock){
    const v = (dock==="top"||dock==="bottom"||dock==="left"||dock==="right") ? dock : "bottom";
    host.removeAttribute('vertical');
    host.style.left = host.style.right = host.style.top = host.style.bottom = '';
    host.style.transform = '';
    if (v === "top"){
      host.style.left = "50%"; host.style.top = "18px"; host.style.transform = "translateX(-50%)";
    } else if (v === "bottom"){
      host.style.left = "50%"; host.style.bottom = "18px"; host.style.transform = "translateX(-50%)";
    } else if (v === "left"){
      host.style.left = "18px"; host.style.top = "50%"; host.style.transform = "translateY(-50%)"; host.setAttribute('vertical','1');
    } else {
      host.style.right = "18px"; host.style.top = "50%"; host.style.transform = "translateY(-50%)"; host.setAttribute('vertical','1');
    }
    try{ chrome.storage.local.set({ [DOCK_KEY]: v }); }catch(e){}
  }
  // default + restore
  applyDock("bottom");
  try{ chrome.storage.local.get({ [DOCK_KEY]:"bottom" }, (r)=>{ const v=r && r[DOCK_KEY]; if(v) applyDock(v); }); }catch(e){}

  // state wire-up
  function setVisible(v){ wrap.style.display = v ? "inline-flex" : "none"; }
  function setActiveMode(force){
    const m=$(".pill.mute"), u=$(".pill.unmute"), a=$(".pill.auto");
    [m,u,a].forEach(b=>b.classList.remove("active"));
    if(force===true){ m.classList.add("active"); if(a) a.textContent="Manual"; }
    else if(force===false){ u.classList.add("active"); if(a) a.textContent="Manual"; }
    else { a.classList.add("active"); if(a) a.textContent="Auto"; }
  }
  function setFromPayload(res){
    if(!res) return;
    const eff = "Now: " + (res.isAd ? "AD" : "content");
    const mut = "Muted: " + (res.muted ? "yes" : "no");
    const reason = res.reason ? (" — " + res.reason) : "";
    const sig = $("#ovl-signal"); if(sig) sig.textContent = eff + "  •  " + mut + reason;
    setActiveMode(res.force);
  }
  function refresh(){ try{ chrome.runtime.sendMessage({type:"GET_STATE"}, (res)=>{ if(res?.ok) setFromPayload(res); }); }catch(e){} }

  $(".pill.mute").addEventListener("click", ()=>{ try{ chrome.runtime.sendMessage({type:"FORCE_STATE", force:true}, refresh); }catch(e){} });
  $(".pill.unmute").addEventListener("click", ()=>{ try{ chrome.runtime.sendMessage({type:"FORCE_STATE", force:false}, refresh); }catch(e){} });
  $(".pill.auto").addEventListener("click", ()=>{
    try{
      chrome.runtime.sendMessage({type:"FORCE_STATE", force:null}, refresh);
      chrome.runtime.sendMessage({type:"FAST_WINDOW", ms:2200});
      chrome.runtime.sendMessage({type:"SYNC_NOW"});
    }catch(e){}
  });
  $(".close").addEventListener("click", ()=> setVisible(false));

  if(isNetflix){
    try{
      chrome.storage.local.get({ admute_nx_mode:"strict" }, (r)=>{
        const btn=$('#nx-mode-btn'); if(!btn) return;
        btn.textContent = (r.admute_nx_mode==="balanced") ? "Balanced" : "Strict";
        btn.addEventListener("click", ()=>{
          chrome.storage.local.get({ admute_nx_mode:"strict" }, (r2)=>{
            const next=(r2.admute_nx_mode==="balanced")?"strict":"balanced";
            chrome.storage.local.set({ admute_nx_mode:next }, ()=>{
              btn.textContent=(next==="balanced")?"Balanced":"Strict";
              chrome.runtime.sendMessage({ type:"NX_MODE", mode:next });
            });
          });
        });
      });
    }catch(e){}
  }

  try{
    chrome.runtime.onMessage.addListener((msg)=>{
      if(msg?.type==="STATE_PUSH") setFromPayload(msg);
      else if(msg?.type==="OVERLAY_TOGGLE"){
        setVisible(wrap.style.display === "none");
        if(wrap.style.display !== "none") refresh();
      }
    });
  }catch(e){}

  // drag+snap using host position (inline anchors)
  let dragging=false, startX=0, startY=0, startRect=null, pointerId=null;
  const HANDLE = shadow.getElementById('admute-bar');
  function nearestDock(){
    const r=host.getBoundingClientRect();
    const vw=Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh=Math.max(document.documentElement.clientHeight, innerHeight||0);
    const cx=r.left + r.width/2, cy=r.top + r.height/2;
    const dist={ top:cy, bottom:vh-cy, left:cx, right:vw-cx };
    let dock="bottom", best=Infinity;
    for(const k of ["top","bottom","left","right"]){ const v=dist[k]; if(v<best){ best=v; dock=k; } }
    return dock;
  }
  function onPointerDown(e){
    if(e.button!==0) return;
    if(e.target.closest("button")) return;
    dragging=true; e.preventDefault();
    pointerId=e.pointerId; try{ HANDLE.setPointerCapture(pointerId); }catch{}
    const r=host.getBoundingClientRect();
    startX=e.clientX; startY=e.clientY; startRect=r;
    host.setAttribute('dragging','1');
    // free move: convert to absolute left/top
    host.style.transition="none";
    host.style.left = r.left + "px";
    host.style.top  = r.top  + "px";
    host.style.right=""; host.style.bottom=""; host.style.transform="translate(0,0)";
  }
  function onPointerMove(e){
    if(!dragging) return;
    const dx=e.clientX-startX, dy=e.clientY-startY;
    const vw=Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh=Math.max(document.documentElement.clientHeight, innerHeight||0);
    const w=startRect.width, h=startRect.height;
    let nx=startRect.left+dx, ny=startRect.top+dy;
    nx=Math.min(Math.max(nx, -w+4), vw-4);
    ny=Math.min(Math.max(ny, -h+4), vh-4);
    host.style.left=nx+"px"; host.style.top=ny+"px";
  }
  function onPointerUp(e){
    if(!dragging) return;
    dragging=false;
    try{ HANDLE.releasePointerCapture(pointerId); }catch{}
    pointerId=null;
    host.removeAttribute('dragging');
    host.style.transition="";
    const dock=nearestDock();
    applyDock(dock);
  }
  HANDLE.addEventListener("pointerdown", onPointerDown);
  document.addEventListener("pointermove", onPointerMove, {passive:true});
  document.addEventListener("pointerup", onPointerUp);
  document.addEventListener("pointercancel", onPointerUp);

  // boot
  setTimeout(()=>{ setVisible(true); refresh(); }, 400);
  let guardUntil=Date.now()+5000;
  (function guard(){ if(Date.now()<guardUntil){ if(wrap.style.display==='none') wrap.style.display='inline-flex'; requestAnimationFrame(guard);} })();
})();
