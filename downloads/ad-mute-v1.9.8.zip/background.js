/* Ad Mute — Continuity Guard | © 2025 Kaboombooo. All rights reserved. Proprietary — see LICENSE.txt. */

const tabState = new Map(); // tabId -> { isAd, force, lastUpdate, reason }
function effective(s){ return s.force != null ? s.force : s.isAd; }
function ensure(tabId){ if(!tabState.get(tabId)) tabState.set(tabId,{ isAd:false, force:null, lastUpdate:0, reason:'' }); return tabState.get(tabId); }
function setMute(tabId, muted){ try{ chrome.tabs.update(tabId, { muted }); }catch(e){} }
function broadcast(tabId){
  const s = ensure(tabId);
  chrome.tabs.get(tabId, (tab) => {
    const payload = { type:'STATE_PUSH', tabId, isAd:!!s.isAd, effective:!!effective(s), force:s.force, muted:!!tab?.mutedInfo?.muted, reason:s.reason||'' };
    try{ chrome.tabs.sendMessage(tabId, payload, ()=>{ void chrome.runtime.lastError; }); }catch(e){}
    try{ chrome.runtime.sendMessage(payload, ()=>{ void chrome.runtime.lastError; }); }catch(e){}
  });
}
function apply(tabId, s, debounce=true){
  const isAd = effective(s);
  if (isAd){
    setMute(tabId, true);
    broadcast(tabId);
  } else {
    setTimeout(()=>{
      const cur = tabState.get(tabId); if(!cur) return;
      if (!effective(cur)) { setMute(tabId, false); broadcast(tabId); }
    }, debounce ? 800 : 0);
  }
}
function handleAdState(tabId, isAd, reason){
  const s = ensure(tabId);
  s.isAd = !!isAd; s.reason = isAd ? (reason || '') : ''; s.lastUpdate = Date.now();
  if (s.force == null) apply(tabId, s, true); else broadcast(tabId);
}
function setForce(tabId, value){
  const s = ensure(tabId);
  s.force = value;
  s.lastUpdate = Date.now();
  apply(tabId, s, false); broadcast(tabId);
}
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  const tabId = msg?.tabId ?? sender?.tab?.id ?? null;
  if (msg?.type === 'AD_STATE'){ if(tabId==null) return send({ok:false}); handleAdState(tabId, !!msg.isAd, msg.reason); return send({ok:true}); }
  if (msg?.type === 'FORCE_STATE'){ if(tabId==null) return send({ok:false}); const toAuto = (msg.force===null); setForce(tabId, toAuto?null:!!msg.force); const s=ensure(tabId);
    try{ if(toAuto && tabId!=null){ chrome.tabs.sendMessage(tabId,{type:'FAST_WINDOW', ms:2200},()=>{void chrome.runtime.lastError;}); chrome.tabs.sendMessage(tabId,{type:'SYNC_NOW'},()=>{void chrome.runtime.lastError;}); } }catch(e){}
    return send({ok:true, force:s.force}); }
  if (msg?.type === 'GET_STATE'){ if(tabId==null) return send({ok:false}); const s=ensure(tabId); chrome.tabs.get(tabId,(tab)=> send({ ok:true, isAd:!!s.isAd, effective:!!effective(s), force:s.force, muted:!!tab?.mutedInfo?.muted, reason:s.reason||'' })); return true; }
  if (msg?.type === 'OVERLAY_TOGGLE'){ if(tabId==null) return send({ok:false}); chrome.tabs.sendMessage(tabId,{type:'OVERLAY_TOGGLE'},()=>{void chrome.runtime.lastError;}); return send({ok:true}); }
  if (msg?.type === 'NX_MODE'){ if(tabId!=null) chrome.tabs.sendMessage(tabId, msg, ()=>{void chrome.runtime.lastError;}); return send({ok:true}); }
});
chrome.tabs.onRemoved.addListener((tabId)=>{ tabState.delete(tabId); });
chrome.commands.onCommand.addListener((cmd)=>{ if(cmd==='toggle-overlay'){ chrome.tabs.query({active:true,currentWindow:true},([tab])=>{ if(tab?.id) chrome.tabs.sendMessage(tab.id,{type:'OVERLAY_TOGGLE'},()=>{void chrome.runtime.lastError;}); }); } });
