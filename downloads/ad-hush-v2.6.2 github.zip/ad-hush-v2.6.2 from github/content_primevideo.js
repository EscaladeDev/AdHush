
/* AdHush — Prime Video (v2.6.9)
   Hotfix: detect parent-split 'Ad' + 'mm:ss' and pseudo-element text; fast mode on any countdown.
   Keeps faster unmute from 2.6.8 (touchdown) and stable reason strings.
*/
(function(){
  'use strict';
  if (window.top !== window) return;
  if (window.__adhushPrime_hotfix) return; window.__adhushPrime_hotfix = true;

  // ---- Tunables ----
  const FAST_MS = 110;
  const SLOW_MS = 900;
  const DEBOUNCE_MS = 110;

  const LATCH_MS = 750;
  const EXIT_CLEAN_SCANS = 1;
  const EXIT_NO_EVIDENCE_MS = 900;
  const TOUCHDOWN_NO_EVIDENCE_MS = 420;

  const COUNTDOWN_TTL_MS = 6500;
  const MIN_DROP = 1;

  const RUNWAY_PAD_MS = 600;
  const MAX_HOSTS = 24, MAX_NODES_PER_HOST = 140, MAX_GLOBAL_NODES = 360;

  // ---- Regexes ----
  const RX_MMSS = /\b([0-5]?\d):([0-5]\d)\b/;
  const RX_AD   = /(^|[\s•:–—-])ad($|[\s•:–—-])/i;
  const RX_NO   = /\b(up\s*next|next episode|autoplay|intro|recap|preview|trailer)\b/i;
  const RX_CTA  = /\b(go ad ?free|why (?:am i seeing|this) ad|skip ads?)\b/i;

  // ---- Utils ----
  const T = (el)=> el ? (el.innerText || el.textContent || '').trim() : '';
  const pseudo = (el)=>{
    try{
      const b = getComputedStyle(el, '::before').content;
      const a = getComputedStyle(el, '::after').content;
      const s = [b,a].filter(x=>x && x!=='none' && x!=='normal').map(x=>x.replace(/^["']|["']$/g,'')).join(' ').trim();
      return s;
    }catch{ return ''; }
  };
  const V = (el)=>{
    if (!el || !el.isConnected) return false;
    const cs = getComputedStyle(el);
    if (cs.display==='none'||cs.visibility==='hidden'||+cs.opacity===0) return false;
    const r = el.getBoundingClientRect();
    return r.width>6 && r.height>6 && r.bottom>0 && r.right>0 &&
           r.left<(innerWidth||1) && r.top<(innerHeight||1);
  };
  const inTL = (el)=>{
    const r=el.getBoundingClientRect();
    const vw=Math.max(document.documentElement.clientWidth, innerWidth||0);
    const vh=Math.max(document.documentElement.clientHeight, innerHeight||0);
    return r.top>=0 && r.top<vh*0.40 && r.left>=0 && r.left<vw*0.58; // slightly larger to be safe
  };
  const aria = (el)=> (el && el.getAttribute && (el.getAttribute('aria-label')||'')) || '';
  const together = (el)=> (T(el)+' '+aria(el)+' '+pseudo(el)).trim();
  const excluded=(el)=>{
    let n=el; for(let i=0;i<6 && n;i++,n=n.parentElement){
      const s=together(n); if (s && RX_NO.test(s)) return true;
    } return false;
  };

  function bigVideo(){
    let best=null, area=0;
    for (const v of document.querySelectorAll('video')){
      const r=v.getBoundingClientRect(), a=r.width*r.height;
      if (a>area){ best=v; area=a; }
    }
    return best;
  }
  function playerRoot(){
    const v=bigVideo(); if(!v) return null;
    return v.closest('.atvwebplayersdk-root, .atvwebplayersdk-player, .webPlayerUIContainer, #dv-web-player') || document.body;
  }

  function eachNodeLimited(root, visit){
    let hosts=0, seen=0; const st=[root];
    while(st.length){
      const n=st.pop(); if(!n || n.nodeType!==1) continue;
      visit(n);
      seen++; if(seen > MAX_HOSTS*MAX_NODES_PER_HOST) break;
      const ch=n.children; if(ch && ch.length){
        const lim=Math.min(ch.length, MAX_NODES_PER_HOST);
        for(let i=0;i<lim;i++) st.push(ch[i]);
      }
      if(n.shadowRoot && ++hosts<=MAX_HOSTS){
        const kids=n.shadowRoot.children||[];
        const lim2=Math.min(kids.length, MAX_NODES_PER_HOST);
        for(let i=0;i<lim2;i++) st.push(kids[i]);
      }
    }
  }

  // adaptive cadence
  let fastUntil=0, timer=null, pending=false;
  function bumpFast(ms=2400){ fastUntil = Date.now()+ms; }
  function cadence(){ return Date.now() < fastUntil ? FAST_MS : SLOW_MS; }
  function schedule(ms){ clearTimeout(timer); timer=setTimeout(scan, ms); }

  // countdown memory + runway
  let lastDrop = { sec:null, at:0 };
  let runwayUntil = 0;
  let lastSeenSec = null;
  let lastEvidenceAt = 0;

  function secFromMatch(m){
    const mi=+m[1], se=+m[2];
    if (Number.isNaN(mi) || Number.isNaN(se)) return NaN;
    return mi*60 + se;
  }
  function noteCountdown(sec){
    lastSeenSec = sec;
    const end = Date.now() + sec*1000 + RUNWAY_PAD_MS;
    if (end > runwayUntil) runwayUntil = end;
    bumpFast(); // NEW: any countdown kicks us into fast scanning to verify drop quickly
  }
  function droppedFromSec(cur){
    const now=Date.now();
    if (now-lastDrop.at>COUNTDOWN_TTL_MS || lastDrop.sec==null){ lastDrop={sec:cur,at:now}; noteCountdown(cur); return false; }
    const d=lastDrop.sec-cur; lastDrop={sec:cur,at:now};
    if (d>=MIN_DROP && d<=90){ noteCountdown(cur); return true; }
    return false;
  }

  // ---- Finders (now include parent-split + pseudo) ----
  function analyzeNode(el){
    const self = together(el);
    if (!self || self.length>60) return null;
    let m = self.match(RX_MMSS);
    let hasAd = RX_AD.test(self);

    // parent split
    if ((!hasAd || !m) && el.parentElement){
      const p = together(el.parentElement);
      if (p){
        if (!m) m = p.match(RX_MMSS);
        if (!hasAd) hasAd = RX_AD.test(p);
      }
    }

    if (!m) return null;
    const sec = secFromMatch(m);
    if (!Number.isFinite(sec)) return null;
    noteCountdown(sec);

    if (hasAd) return { score:3, sec, reason:'explicit Ad mm:ss' };
    return { score:2, sec, reason:'mm:ss-only' };
  }

  function findBadgeIn(root){
    let best=null;
    eachNodeLimited(root, (el)=>{
      if (!V(el) || !inTL(el) || excluded(el)) return;
      const res = analyzeNode(el);
      if (!res) return;
      if (res.score===3){ best=res; return; }
      if (!best) best=res;
    });
    return best;
  }
  function findBadgeGlobal(){
    const nodes=document.querySelectorAll('span,div,button,a'); let checked=0, best=null;
    for(const el of nodes){
      if(++checked>MAX_GLOBAL_NODES) break;
      if(!V(el) || !inTL(el) || excluded(el)) continue;
      const res = analyzeNode(el);
      if (!res) continue;
      if (res.score===3){ best=res; break; }
      if (!best) best=res;
    }
    return best;
  }
  function cheapHints(){
    const r=playerRoot(); if(!r) return false;
    const s=together(r); return !!(s && RX_CTA.test(s));
  }

  // state + latches
  let state={ isAd:false, reason:'content' }, latchUntil=0, cleanScans=0;

  function step(){
    const root=playerRoot();
    let badge = root ? findBadgeIn(root) : null;
    if(!badge) badge = findBadgeGlobal();

    let evidence=false;

    if (badge){
      if (badge.score===3){ evidence=true; }
      else if (Number.isFinite(badge.sec) && droppedFromSec(badge.sec)){ evidence=true; }
    } else if (cheapHints()){ evidence=true; }

    if (evidence){
      lastEvidenceAt = Date.now();
      latchUntil = lastEvidenceAt + LATCH_MS;
    }

    const onRunway = Date.now() < runwayUntil;
    const latched = onRunway || (Date.now() < latchUntil);

    let next = state.isAd;
    if (!state.isAd){
      if (evidence || onRunway){ next = true; cleanScans=0; }
    } else {
      const noEvFor = Date.now() - lastEvidenceAt;
      const nearTouchdown = (lastSeenSec != null && lastSeenSec <= 2);
      if (!latched){
        if (evidence){ next = true; cleanScans=0; }
        else {
          cleanScans++;
          if (cleanScans >= EXIT_CLEAN_SCANS || noEvFor >= EXIT_NO_EVIDENCE_MS || (nearTouchdown && noEvFor >= TOUCHDOWN_NO_EVIDENCE_MS)){
            next=false; cleanScans=0;
          }
        }
      } else cleanScans=0;
    }

    return next;
  }

  function publish(isAd){
    if (state.isAd === isAd) return;
    state = { isAd, reason: isAd ? 'ad' : 'content' };
    try{ chrome.runtime.sendMessage({ type:'AD_STATE', isAd: state.isAd, reason: state.reason }); }catch{}
    document.dispatchEvent(new CustomEvent('adhush:state',{ detail:{ site:'primevideo', isAd: state.isAd, reason: state.reason, ts:Date.now() }}));
    try{ window.postMessage({ source:'adhush', site:'primevideo', type:'state', isAd: state.isAd, reason: state.reason, ts:Date.now() }, '*'); }catch{}
  }

  function scan(){ pending=false; const next = step(); publish(next); schedule(cadence()); }
  function debounced(){ if(pending) return; pending=true; setTimeout(scan, DEBOUNCE_MS); }

  // observe + run
  let mo;
  function watch(){
    const r=playerRoot(); try{ if(mo) mo.disconnect(); }catch{}
    if(!r) return;
    mo=new MutationObserver(debounced);
    try{ mo.observe(r, { subtree:true, childList:true, attributes:true, characterData:true }); }catch{}
  }
  watch(); scan();
  ['popstate','pushstate','hashchange','pageshow','visibilitychange'].forEach(e => addEventListener(e, ()=>{ watch(); debounced(); }, { passive:true }));
  (function hook(){ const o=history.pushState; history.pushState=function(){ const r=o.apply(this,arguments); try{ dispatchEvent(new Event('pushstate')); }catch{} return r; }; })();

  window.__ADHUSH_PRIMEVIDEO__ = { state:()=>state };
})();
