(function(){try{chrome.runtime.sendMessage({type:'PAGE_PING', site:'youtube'});}catch(e){}})();
