(function(){try{chrome.runtime.sendMessage({type:'PAGE_PING', site:'netflix'});}catch(e){}})();
