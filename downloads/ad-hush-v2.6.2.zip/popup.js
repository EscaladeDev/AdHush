(function(){
  'use strict';
  const $ = s => document.querySelector(s);

  function fmtHM(ms){
    const totalMin = Math.floor((ms||0)/60000);
    const h = Math.floor(totalMin/60);
    const m = totalMin%60;
    return `${h}h ${String(m).padStart(2,'0')}m`;
  }
  const label = k => (k==='unknown' ? 'other' : k);

  function render(stats){
    stats = stats || {};
    const total = stats.totalAdMutedMs||0;
    const count = stats.totalAdSessions||0;
    $('#total').textContent = fmtHM(total);
    $('#count').textContent = `Ads: ${count}`;

    const sitesMs = stats.bySite||{};
    const sitesCount = stats.bySiteCount||{};
    const wrap = $('#sites');
    wrap.textContent='';
    const SUPPORTED_SITES = [
      { key:'youtube',    label:'YouTube'   },
      { key:'netflix',    label:'Netflix'   },
      { key:'disneyplus', label:'Disney+'   },
      { key:'spotify',    label:'Spotify'   },
    ];
    for (const s of SUPPORTED_SITES){
      const k = s.key;
      const v = sitesMs[k]||0;
      const c = sitesCount[k]||0;
      const row = document.createElement('div');
      row.className = 'site';
      row.innerHTML = `<span class="label">${s.label}</span>
                       <span class="count">×${c}</span>
                       <span class="time">${fmtHM(v)}</span>`;
      wrap.appendChild(row);
    }
    let otherMs = 0, otherCount = 0;
    for (const [kk, vv] of Object.entries(sitesMs)){
      if (!SUPPORTED_SITES.some(x=>x.key===kk)) otherMs += vv;
    }
    for (const [kk, vv] of Object.entries(sitesCount)){
      if (!SUPPORTED_SITES.some(x=>x.key===kk)) otherCount += vv;
    }
    if (otherMs>0 || otherCount>0){
      const row = document.createElement('div');
      row.className = 'site';
      row.innerHTML = `<span class=\"label\">other</span>
                       <span class=\"count\">×${otherCount}</span>
                       <span class=\"time\">${fmtHM(otherMs)}</span>`;
      wrap.appendChild(row);
    }

    if (top.length===0){
      const empty = document.createElement('div');
      empty.className='site';
      empty.innerHTML = '<span class="label">No data yet</span><span class="time">—</span>';
      wrap.appendChild(empty);
    }
  }

  function load(){
    // Try runtime API first
    try{
      chrome.runtime.sendMessage({type:'GET_STATS'}, res => {
        if (chrome.runtime.lastError) { fallback(); return; }
        if (res && res.ok && res.stats){ render(res.stats); }
        else { fallback(); }
      });
    }catch(e){ fallback(); }

    function fallback(){
      try{
        chrome.storage.local.get('adhush_stats', out => render(out.adhush_stats));
      }catch(_){ render({}); }
    }
  }

  $('#toggleOverlay').addEventListener('click', ()=>{
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      const tab = tabs && tabs[0]; if (!tab?.id) return;
      try { chrome.tabs.sendMessage(tab.id, { type:'OVERLAY_TOGGLE' }); } catch {}
      window.close();
    });
  });

  document.addEventListener('visibilitychange', ()=>{
    if (document.visibilityState === 'visible') load();
  });
  chrome.storage.onChanged.addListener((chg, area)=>{
    if (area==='local' && chg.adhush_stats) load();
  });

  load();
})();