/* AdHush | © 2025 Kaboombooo. All rights reserved. Proprietary — see EULA.txt. */
try { chrome.runtime.sendMessage({type:'PAGE_PING', site:'disneyplus'}); } catch(e) {}

(function(){
  if (window.__admuteDisneyLoaded) return; window.__admuteDisneyLoaded = true;
  function normText(x){ if (x==null) return ''; if (typeof x==='string') return x; if (typeof x==='number'||typeof x==='boolean') return String(x); if (typeof x==='object' && typeof x.baseVal==='string') return x.baseVal; try { return String(x);} catch(e){return '';} }
  function isVisible(el){ if (!el) return false; const st = getComputedStyle(el); if (st.display==='none'||st.visibility==='hidden'||+st.opacity===0) return false; const r=el.getClientRects(); return r && r.length>0; }
  function rect(el){ try { return el.getBoundingClientRect(); } catch(e){ return {x:0,y:0,width:0,height:0}; } }
  function walkDeep(root, visit, cap=6000){ const stack=[root]; let n,c=0; while(stack.length && c<cap){ n=stack.pop(); if(!n) continue; c++; visit(n); if(n.shadowRoot) stack.push(n.shadowRoot); const ch=n.children||n.childNodes; if(ch&&ch.length){ for(let i=ch.length-1;i>=0;i--) stack.push(ch[i]); } } }
  function deepText(n){ return normText(n && (n.innerText||n.textContent) || ''); }
  const RX_TIMER=/\b\d{1,2}:\d{2}\b/, RX_LEARN=/\blearn more\b/i, RX_AD_OF=/\bad\s+\d+\s+of\s+\d+\b/i, RX_AD=/(^|[\s•:–—-])ad($|[\s•:–—-])/i;
  function scanForAd(root){ const vw=Math.max(document.documentElement.clientWidth,innerWidth||0); const vh=Math.max(document.documentElement.clientHeight,innerHeight||0); let found=false, reason='';
    walkDeep(root, (el)=>{ if(found) return; if(el.nodeType!==1 || !isVisible(el)) return; const t=deepText(el).trim(); if(!t) return;
      if(/^ad$/i.test(t)||RX_AD.test(t)){ const p=el.parentElement||el; const pt=deepText(p); const r=rect(p); const inBL=(r.x<vw*0.40)&&(r.y>vh*0.58); if((RX_TIMER.test(pt)||RX_LEARN.test(pt)||RX_AD_OF.test(pt)) && inBL){ found=true; reason='disney+: chip bottom-left'; return; } } });
    if(found) return { isAd:true, reason };
    let score=0;
    walkDeep(root,(el)=>{ if(found) return; if(el.nodeType!==1 || !isVisible(el)) return; const t=deepText(el).trim(); if(!t) return;
      if(RX_AD_OF.test(t)) score+=3; if(/\bad\s+break/i.test(t)) score+=2; if(/\badvertisement|commercial/i.test(t)) score+=2; if(RX_AD.test(t)&&RX_TIMER.test(t)) score+=2; if(RX_LEARN.test(t)&&RX_AD.test(t)) score+=2; if(score>=3){ found=true; reason='disney+: text signals'; } });
    return { isAd:found, reason };
  }
  const state={ isAd:false, lastChange:0, timer:0, lastTick:0, raf:0, misses:0, fastUntil:0 };
  const FAST=100, NORMAL=220;
  function schedule(ms){ cancelAnimationFrame(state.raf); clearTimeout(state.timer); state.timer=setTimeout(tick, ms); }
  function tickSoon(){ const now=Date.now(); if(now-state.lastTick>50){ cancelAnimationFrame(state.raf); clearTimeout(state.timer); state.raf=requestAnimationFrame(tick); } }
  document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) tickSoon(); });
  function getRoot(){ const v=document.querySelector('video'); if(!v) return document.body; const r=v.closest('[role=\"application\"],[data-testid*=\"player\"],[class*=\"player\"],[class*=\"hud\"],[class*=\"controls\"]'); return r||v.parentElement||document.body; }
  function send(isAd, meta){ if(state.isAd===isAd) return; state.isAd=isAd; state.lastChange=Date.now(); chrome.runtime.sendMessage({ type:'AD_STATE', isAd, reason: meta && meta.reason }); if(meta&&meta.reason) console.debug('[Ad Mute][Disney+] reason:', meta.reason); }
  function tick(){ try{ state.lastTick=Date.now(); const root=getRoot(); let meta=scanForAd(root); if(!meta.isAd){ state.misses++; if(state.misses%8===0){ const m2=scanForAd(document.body); if(m2.isAd) meta=m2; } } else state.misses=0; send(!!meta.isAd, meta); const since=Date.now()-state.lastChange; schedule((meta.isAd||since<2000)?Math.min(80,FAST):((Date.now()<state.fastUntil)?120:NORMAL)); }catch(e){ schedule(300); } }
  tick();
  let mo=new MutationObserver(()=>tickSoon());
  function watchRoot(){ const r=getRoot(); try{ mo.disconnect(); mo.observe(r,{subtree:true,childList:true,characterData:true}); }catch(e){} }
  watchRoot();
  (function hookVideo(){ const v=document.querySelector('video'); if(!v){ setTimeout(hookVideo,800); return; } v.addEventListener('timeupdate',tickSoon,{passive:true}); v.addEventListener('seeking',tickSoon,{passive:true}); v.addEventListener('ratechange',tickSoon,{passive:true}); setInterval(watchRoot,2000); })();

  chrome.runtime.onMessage.addListener((msg)=>{
    try{
      if(msg && msg.type==='FAST_WINDOW'){ if(typeof msg.ms==='number'){ state.fastUntil=Date.now()+msg.ms; } }
      if(msg && msg.type==='SYNC_NOW'){
        let isAd=false, reason='';
        const r=(function(){ const v=document.querySelector('video'); const root = v? (v.closest('[role=\"application\"],[data-testid*=\"player\"],[class*=\"player\"],[class*=\"hud\"],[class*=\"controls\"]')||document.body) : document.body; return scanForAd(root); })();
        isAd=!!r.isAd; reason=r.reason||'';
        chrome.runtime.sendMessage({ type:'AD_STATE', isAd: !!isAd, reason: reason || 'disney+: sync' });
      }
    }catch(e){}
  });
})();
