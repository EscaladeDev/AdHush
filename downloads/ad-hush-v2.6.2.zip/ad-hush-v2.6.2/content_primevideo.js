/* AdHush — Prime Video detection (v2.6.2 prime-only r3) */
(function () {
  'use strict';

  try { chrome.runtime.sendMessage({ type: 'PAGE_PING', site: 'primevideo' }); } catch {}

  const isPrimeWatch = /amazon\.(com|co\.uk|de|fr|it|es|co\.jp|in|com\.au)\/gp\/video\//i.test(location.href);
  if (!isPrimeWatch) return;

  // Tunables
  const DEBUG = false;
  const SCORE_TO_AD = 3;   // global badge alone >= 3
  const HYST_ON_MS  = 450;
  const HYST_OFF_MS = 600;
  const EVAL_THROTTLE_MS = 250;
  const SHORT_DURATION_S = 150;
  const MIN_SEEKABLE_S   = 6;

  let lastEvalTS = 0;
  let stable = { isAd: false, reason: '' };
  let pendingFlipSince = 0;
  let lastSent = { isAd: null, reason: '' };

  function log(...a){ if (DEBUG) console.log('[AdHush:prime]', ...a); }
  function now(){ return performance.now ? performance.now() : Date.now(); }

  function visibleRect(el){
    if (!el || typeof el.getBoundingClientRect !== 'function') return null;
    const r = el.getBoundingClientRect();
    const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
    const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
    if (r.bottom <= 0 || r.right <= 0 || r.left >= vw || r.top >= vh) return null;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return null;
    return r;
  }

  function getPrimaryVideo(){
    const vids = Array.from(document.querySelectorAll('video'));
    let best=null, area=0;
    for (const v of vids){
      const r = visibleRect(v); if (!r) continue;
      const a = r.width*r.height; if (a>area){ best=v; area=a; }
    }
    return best;
  }

  function textOf(el){
    if (!el) return '';
    let t = '';
    try { t = el.innerText || el.textContent || ''; } catch {}
    if (!t) try { t = el.getAttribute('aria-label') || ''; } catch {}
    return (t||'').replace(/\s+/g,' ').trim();
  }

  // Scan an element subtree for a visible badge like "Ad 1:49"
  function hasAdBadgeIn(root){
    const RX_BADGE = /\bAd\s*\d{1,2}:\d{2}\b/i;
    const RX_LOOSE = /\bAd\b.*\b\d{1,2}:\d{2}\b/i;

    // Light but broad candidate set
    const nodes = Array.from(root.querySelectorAll('span,div,strong,em,b,i,button,[role],[aria-label],[data-testid],[data-automation-id],[class*="ad"],[class*="Ad"]'));
    for (const el of nodes){
      if (!visibleRect(el)) continue;
      const s = textOf(el);
      if (!s) continue;
      if (RX_BADGE.test(s) || RX_LOOSE.test(s)) return true;
    }

    // aria-live regions sometimes host the countdown text
    const live = Array.from(root.querySelectorAll('[aria-live]'));
    for (const el of live){
      if (!visibleRect(el)) continue;
      if (RX_BADGE.test(textOf(el)) || RX_LOOSE.test(textOf(el))) return true;
    }

    return false;
  }

  // Same-origin iframes (Prime sometimes nests UI)
  function anyIframeHasBadge(){
    const frames = Array.from(document.querySelectorAll('iframe'));
    for (const f of frames){
      try {
        if (!f.contentDocument) continue;
        const doc = f.contentDocument;
        const body = doc.body || doc.documentElement;
        if (!body) continue;
        if (hasAdBadgeIn(body)) return true;
      } catch { /* cross-origin; ignore */ }
    }
    return false;
  }

  function collectViewportText(){
    let txt = '';
    try { txt += (document.body && document.body.innerText) || ''; } catch {}
    return (txt||'').toLowerCase().replace(/\s+/g,' ').slice(0, 100000);
  }

  function send(state){
    if (state.isAd === lastSent.isAd && state.reason === lastSent.reason) return;
    lastSent = state;
    try { chrome.runtime.sendMessage({ type: 'AD_STATE', isAd: state.isAd, reason: state.reason }); } catch {}
    log('AD_STATE ->', state);
  }

  function scoreSignals(){
    let score = 0;
    const reasons = [];

    // A) Global badge anywhere (decisive)
    const badge =
      hasAdBadgeIn(document.body || document.documentElement) || anyIframeHasBadge();
    if (badge){ score += 3; reasons.push('badge'); }

    // B) Common textual hints (union view)
    const text = collectViewportText();
    if (/\b(ad\s*\d+\s*of\s*\d+)\b/.test(text)) { score += 1; reasons.push('ad-N-of-M'); }
    if (/\b(skip|skip ad|skip ads|ends in\s*\d+)\b/.test(text)) { score += 1; reasons.push('skip/ends-in'); }

    // C) Video properties (weak)
    const v = getPrimaryVideo();
    if (v){
      try {
        if (Number.isFinite(v.duration) && v.duration>0 && v.duration<SHORT_DURATION_S){
          score += 1; reasons.push('short-duration');
        }
      } catch {}
      try {
        const sr = v.seekable;
        if (sr && sr.length>0){
          const range = sr.end(0)-sr.start(0);
          if (!Number.isNaN(range) && range < MIN_SEEKABLE_S){ score += 1; reasons.push('unseekable'); }
        }
      } catch {}
    }

    return { score, reasons: reasons.join(', ') };
  }

  function evaluate(){
    const t = now();
    if (t - lastEvalTS < EVAL_THROTTLE_MS) return;
    lastEvalTS = t;

    const { score, reasons } = scoreSignals();
    const wantAd = score >= SCORE_TO_AD;
    const needMs = wantAd ? HYST_ON_MS : HYST_OFF_MS;

    if (wantAd !== stable.isAd){
      if (!pendingFlipSince) pendingFlipSince = t;
      if (t - pendingFlipSince >= needMs){
        stable = { isAd: wantAd, reason: `prime:${score} [${reasons}]` };
        pendingFlipSince = 0;
        send(stable);
      }
    } else {
      pendingFlipSince = 0;
      if (stable.isAd && stable.reason !== `prime:${score} [${reasons}]`){
        stable = { isAd: true, reason: `prime:${score} [${reasons}]` };
        send(stable);
      }
    }
  }

  function schedule(){
    evaluate();
    try { cancelAnimationFrame(schedule._raf); } catch {}
    schedule._raf = requestAnimationFrame(evaluate);
  }

  const mo = new MutationObserver(schedule);
  try { mo.observe(document.documentElement, { subtree:true, childList:true, attributes:true, characterData:true }); } catch {}
  window.addEventListener('play', schedule, true);
  window.addEventListener('pause', schedule, true);
  window.addEventListener('timeupdate', schedule, true);
  window.addEventListener('ratechange', schedule, true);
  window.addEventListener('loadedmetadata', schedule, true);
  window.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') schedule(); }, { passive:true });

  schedule();
})();
