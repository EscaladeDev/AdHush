(function(){try{chrome.runtime.sendMessage({type:'PAGE_PING', site:'spotify'});}catch(e){}})();
