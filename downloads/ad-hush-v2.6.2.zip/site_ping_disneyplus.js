(function(){try{chrome.runtime.sendMessage({type:'PAGE_PING', site:'disneyplus'});}catch(e){}})();
